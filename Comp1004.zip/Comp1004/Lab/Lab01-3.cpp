//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 1-3
#include <iostream>
using namespace std;
#include "svg.h"

int main()
{
	svgout<<"rect   100 100 400 400 15 blue none";
	svgout<<"line   250 150 250 250 15 green";
	svgout<<"line   350 150 350 250 15 green";
	svgout<<"line   250 250 150 250 15 green";
	svgout<<"line   350 250 450 250 15 green";
	svgout<<"circle 300 400  50  15 red none";
	svgout<<"text    80 600  50 black Arial COMP1004@HKUST";
	return 0;
}
