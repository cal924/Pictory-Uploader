//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 7
/*
#include <iostream>
#include <cstring>
using namespace std;

const int InputMax = 1024;	// Maximum length of input string
char Input[InputMax+1];		// Array holding the user input

const int WordMax = 300;	// Maximum number of words
const int WordLengMax = 20;	// Maximum length of a word
int Words[WordMax][2];		// Words[][0]for storing the location of the word
							// Words[][1]for storing the length of the word
int NumWord = 0;			// Number of words

const int SymMax = 100;		// Maximum number of symbols
char Symbols[SymMax];		// Array holding symbol characters in user input
int NumSym = 0;				// Number of symbols

const int IntMax = 100;		// Maximum number of integers
int Integers[IntMax][2];	// Array holding integers in user input
int NumInt = 0;				// Number of integers

int main()
{
	//TODO Obtain input
	cout<<"Enter the string to be processed : ";
	cin.getline(Input, InputMax+1, '\n');

	//TODO Initialization
	int Length = strlen(Input);
	for (int i=0 ; i < WordMax ; i++)
	{
		Words[i][0] = 0;
		Words[i][1] = 0;
	}

	//TODO Identify the tokens
	int i = 0;
	while (i < Length)
	{
		if ( isalpha(Input[i]) )
		{
			Words[NumWord][0] = i;
			NumWord++;
			while ( isalpha(Input[i]))
			{
				Words[NumWord-1][1] ++;
				i++;
			}
		}
		else if ( isdigit(Input[i]) )
		{
			Integers[NumInt][0] = i;
			NumInt++;
			while ( isdigit(Input[i]) )
			{
				Integers[NumInt-1][1]++;
				i++;
			}
		}
		else if ( !(isspace(Input[i])) )
		{
			Symbols[NumSym] = Input[i];
			NumSym++;
			i++;
		}
		while ( isspace(Input[i]) )
			i++;
	}

	//TODO Remove zeros and pretend it is an integer
	for (int i=0 ; i < NumInt ; i++)
		while (Input[ Integers[i][0] ] == '0' && Integers[i][1] != 1)
		{
			Integers[i][0]++;
			Integers[i][1]--;
		}

	//TODO Display the output
	cout<<NumWord<<" Word(s):\t";
	for (int i=0 ; i < NumWord ; i++)
	{
		for (int j = Words[i][0] ; j < Words[i][0] + Words[i][1] ; j++)
			cout<<Input[j];
		cout<<'\t';
	}

	cout<<'\n'<<NumSym<<" symbols(s):\t";
	for (int i=0 ; i < NumSym ; i++)
		cout<<Symbols[i]<<'\t';

	cout<<'\n'<<NumInt<<" integers(s):\t";
	for (int i=0 ; i < NumInt ; i++)
	{
		for (int j = Integers[i][0] ; j < Integers[i][0] + Integers[i][1] ; j++)
			cout<<Input[j];
		cout<<'\t';
	}
}
*/
