//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 4

#include <iostream>
#include<ctime>
#include <cstdlib>
using namespace std;
#include "svg.h"

//Function for drawing pattern1
void pattern1 (int x, int y, float size, int ring)
{
	svgout << "circle" << x << y;
	switch (ring)
	{
	case 0:
		svgout << (size / 4)     << "0 none white";
		break;
	case 1:
		svgout << (size / 2)     << "0 none blue";
		break;
	case 2:
		svgout << (size * 3 / 4) << "0 none white";
		break;
	case 3:
		svgout << (size)         << "0 none blue";
		break;
	}
}

//Function for drawing pattern2
void pattern2 (int x, int y, float size, int ring)
{
	svgout << "circle" << x << y;
	switch (ring)
	{
	case 0:
		svgout << (size / 2)     << "0 none white";
		break;
	case 1:
		svgout << (size * 3 / 4) << "0 none red";
		break;
	case 2:
		svgout << (size * 7 / 8) << "0 none white";
		break;
	case 3:
		svgout << (size)         << "0 none red";
		break;
	}
}

//Function for drawing pattern3
void pattern3 (int x, int y, float size, int ring)
{
	svgout << "circle" << x << y;
	switch (ring)
	{
	case 0:
		svgout << (size / 2)     << "0 none brown";
		break;
	case 1:
		svgout << (size * 5 / 8) << "0 none white";
		break;
	case 2:
		svgout << (size)         << "0 none brown";
		break;
	}
}

//Function for drawing pattern4
void pattern4 (int x, int y, float size, int ring)
{
	svgout << "circle" << x << y;
	switch (ring)
	{
	case 0:
		svgout << (size / 3)       << "0 none white";
		break;
	case 1:
		svgout << (size * 2 / 3)   << "0 none green";
		break;
	case 2:
		svgout << (size * 29 / 30) << "0 none white";
		break;
	case 3:
		svgout << (size)           << "0 none green";
		break;
	}
}

//Function for drawing pattern5
void pattern5 (int x, int y, float size, int ring)
{
	svgout << "circle" << x << y;
	switch (ring)
	{
	case 0:
		svgout << (size / 2)     << "0 none white";
		break;
	case 1:
		svgout << (size * 3 / 4) << "0 none magenta";
		break;
	case 2:
		svgout << (size * 7 / 8) << "0 none white";
		break;
	case 3:
		svgout << (size)         << "0 none magenta";
		break;
	}
}

//Function for drawing pattern6
void pattern6 (int x, int y, float size, int ring)
{
	svgout << "circle" << x << y;
	switch (ring)
	{
	case 0:
		svgout << (size * 5 / 8)   << "0 none yellow";
		break;
	case 1:
		svgout << (size * 19 / 20) << "0 none white";
		break;
	case 2:
		svgout << (size)           << "0 none yellow";
		break;
	}
}


int main()
{
	const int radius = 10;

	//For Drawing pattern 1
	for(int i=3 ; i>=0 ; i--)
		pattern1(50, 50, radius, i);
	for(int i=0 ; i<=3 ; i++)
		for(int j=0 ; j<=3 ; j++)
			for(int k=3 ; k>=0 ; k--)
				pattern1( (100+15*i), (50+15*j), radius, k);

	//For Drawing pattern 2
	for(int i=3 ; i>=0 ; i--)
		pattern2(50, 150, radius, i);
	for(int k=3 ; k>=0 ; k--)
		for(int i=0 ; i<=3 ; i++)
			for(int j=0 ; j<=3 ; j++)
				pattern2( (100+15*i), (150+15*j), radius, k);

	//For Drawing pattern 3
	for(int i=2 ; i>=0 ; i--)
		pattern3(50, 250, radius, i);
	for(int k=2 ; k>=0 ; k--)
		for(int i=0 ; i<=3 ; i++)
			for(int j=0 ; j<=3 ; j++)
				pattern3( (100+15*i), (250+15*j), radius, k);

	//For Drawing pattern 4
	for(int i=3 ; i>=0 ; i--)
		pattern4(250, 50, radius, i);
	for(int i=0 ; i<=3 ; i++)
		for(int j=0 ; j<=3 ; j++)
			for(int k=3 ; k>=0 ; k--)
				pattern4( (300+15*i), (50+15*j), ( (j%2)?(radius * 3 / 2):radius ), k);

	//For Drawing pattern 5
	for(int i=3 ; i>=0 ; i--)
		pattern5(250, 150, radius, i);
	for(int k=3 ; k>=2 ; k--)
		for(int j=0 ; j<=3 ; j++)
			for(int i=0 ; i<=3 ; i++)
				pattern5( (300+15*i), (150+15*j), ( (j%2)?(radius * 3 / 2):radius ), k);
	for(int j=0 ; j<=3 ; j++)
		for(int i=0 ; i<=3 ; i++)
			for(int k=1 ; k>=0 ; k--)
				pattern5( (300+15*i), (150+15*j), ( (j%2)?(radius * 3 / 2):radius ), k);

	//For Drawing pattern 6
	for(int i=2 ; i>=0 ; i--)
		pattern6(250, 250, radius, i);
	for(int j=0 ; j<=3 ; j++)
		for(int i=0 ; i<=3 ; i++)
			pattern6( (300+15*i), (250+15*j), ( (j%2)?(radius * 3 / 2):radius ), 2);
	for(int j=0 ; j<=3 ; j++)
		for(int i=0 ; i<=3 ; i++)
			for(int k=1 ; k>=0 ; k--)
				pattern6( (300+15*i), (250+15*j), ( (j%2)?(radius * 3 / 2):radius ), k);

	//Start Random
	srand((unsigned)time(0));
	int rand_x, rand_y, rand_num;
	float rand_size;

	//Random Pattern 1
	for(int i=3 ; i>=0 ; i--)
		pattern1(450, 50, 10, i);
	rand_num = 4;
	for(int i=0 ; i<=rand_num ; i++)
		for(int j=0 ; j<=rand_num ; j++)
		{
			rand_x = rand()%10 - 10;
			rand_y = rand()%10 - 10;
			rand_size = rand()%50 / 10.0 + 8;
			for(int k=3 ; k>=0 ; k--)
				pattern1(rand_x+500+17*i, 50+17*j+rand_y, rand_size, k);
		}

	//Random Pattern 2
	for(int i=3 ; i>=0 ; i--)
		pattern2(450, 150, 10, i);
	rand_num = 3;
	for(int i=0 ; i<=rand_num ; i++)
		for(int j=0 ; j<=rand_num ; j++)
		{
			rand_x = rand()%10 - 10;
			rand_y = rand()%10 - 10;
			rand_size = rand()%50 / 10.0 + 10;
			for(int k=3 ; k>=0 ; k--)
				pattern2(rand_x+500+17*i, 150+17*j+rand_y, rand_size, k);
		}

	//Random Pattern 3
	for(int i=2 ; i>=0 ; i--)
		pattern3(450, 250, 10, i);
	rand_num = 2;
	for(int i=0 ; i<=rand_num ; i++)
		for(int j=0 ; j<=rand_num ; j++)
		{
			rand_x = rand()%10 - 10;
			rand_y = rand()%10 - 10;
			rand_size = rand()%50 / 10.0 + 10;
			for(int k=2 ; k>=0 ; k--)
				pattern3(rand_x+500+17*i, 250+17*j+rand_y, rand_size, k);
		}

	//Random Pattern 4
	for(int i=3 ; i>=0 ; i--)
		pattern4(650, 50, 10, i);
	rand_num = 4;
	for(int i=0 ; i<=rand_num ; i++)
		for(int j=0 ; j<=rand_num ; j++)
		{
			rand_x = rand()%10 - 10;
			rand_y = rand()%10 - 10;
			rand_size = rand()%50 / 10.0 + 10;
			for(int k=3 ; k>=0 ; k--)
				pattern4(rand_x+700+17*i, 50+17*j+rand_y, rand_size, k);
		}

	//Random Pattern 5
	for(int i=3 ; i>=0 ; i--)
		pattern5(650, 150, 10, i);
	rand_num = 3;
	for(int i=0 ; i<=rand_num ; i++)
		for(int j=0 ; j<=rand_num ; j++)
		{
			rand_x = rand()%10 - 10;
			rand_y = rand()%10 - 10;
			rand_size = rand()%50 / 10.0 + 10;
			for(int k=3 ; k>=0 ; k--)
				pattern5(rand_x+700+17*i, 150+17*j+rand_y, rand_size, k);
		}

	//Random Pattern 6
	for(int i=2 ; i>=0 ; i--)
		pattern6(650, 250, 10, i);
	rand_num = 5;
	for(int i=0 ; i<=rand_num ; i++)
		for(int j=0 ; j<=rand_num ; j++)
		{
			rand_x = rand()%10 - 10;
			rand_y = rand()%10 - 10;
			rand_size = rand()%50 / 10.0 + 10;
			for(int k=2 ; k>=0 ; k--)
				pattern6(rand_x+700+17*i, 250+17*j+rand_y, rand_size, k);
		}
	return 0;


}
