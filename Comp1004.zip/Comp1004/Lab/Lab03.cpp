//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 3

#include <iostream>
using namespace std;
#include "svg.h"

void PrintRow (int Row, int N)
{
	int Num = 0;
	cout<<"Enter number "<<Row<<" : ";
	cin>>Num;
	for(int i=1;i<=N;i++)
	{
		svgout<<"rect"<<(N - i + 2) * 20<<Row * 20<<"20 20 0 none"<<((Num%2)?"white":"black");
		Num /= 2;
	}

}

int main()
{
	int N = 0;
	cout<<"Enter the size (N) of the matrix (between 2 to 10): ";
	cin>>N;
	for (int j=1;j<=N;j++)
		PrintRow(j,N);
	return 0;
}

