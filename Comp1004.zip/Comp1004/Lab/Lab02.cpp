//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 2

#include<iostream>
using namespace std;

int main()
{
	const int Cost1 = 1490, Cost2 = 1970,
			  Cost3 = 2630, Cost4 = 3760,
			  Cost5 = 5890;

	int Q1, Q2, Q3, Q4, Q5;
	int Discount;
	int Price1  , Price2        , Price3 , Price4  , Price5,
	    SubTotal, DiscountAmount, Total  ,
	    PaidD   , PaidC         , Paid   , Returns ;
	int HundredD, FiftyD, TwentyD, TenD,
		FiveD   , TwoD  , OneD,
		FiveC   , TwoC  , OneC;

//Ask for Quantity
	cout<<"Quantity of item 1 (price = $14.90):    ";
	cin>>Q1;
	cout<<"Quantity of item 2 (price = $19.70):    ";
	cin>>Q2;
	cout<<"Quantity of item 3 (price = $26.30):    ";
	cin>>Q3;
	cout<<"Quantity of item 4 (price = $37.60):    ";
	cin>>Q4;
	cout<<"Quantity of item 5 (price = $58.90):    ";
	cin>>Q5;
	cout<<"Discount Rate (in percentage):  ";
	cin>>Discount;

//Calculate the Price of each item and discout
	Price1 = Q1 * Cost1;
	Price2 = Q2 * Cost2;
	Price3 = Q3 * Cost3;
	Price4 = Q4 * Cost4;
	Price5 = Q5 * Cost5;

	SubTotal = Price1 + Price2 + Price3 + Price4 + Price5;
	DiscountAmount = Discount * SubTotal / 100;
	DiscountAmount -= DiscountAmount%10;
	Total  = SubTotal - DiscountAmount;

//Show Summary of Purchase
	cout<<"---------------------------";
	cout<<"\nSummary of the purchase";
	cout<<"\nItem 1 x "<<Q1<<" =    $"<<Price1/100<<"."<<(Price1%100)/10<<"0";
	cout<<"\nItem 2 x "<<Q2<<" =    $"<<Price2/100<<"."<<(Price2%100)/10<<"0";
	cout<<"\nItem 3 x "<<Q3<<" =    $"<<Price3/100<<"."<<(Price3%100)/10<<"0";
	cout<<"\nItem 4 x "<<Q4<<" =    $"<<Price4/100<<"."<<(Price4%100)/10<<"0";
	cout<<"\nItem 5 x "<<Q5<<" =    $"<<Price5/100<<"."<<(Price5%100)/10<<"0";

	cout<<"\n---------------------------";
	cout<<"\nSubtotal        $"<<SubTotal/100<<"."<<(SubTotal%100)/10<<"0";
	cout<<"\nDiscount        $"<<DiscountAmount/100<<"."<<(DiscountAmount%100)/10<<"0";
	cout<<"\n---------------------------";
	cout<<"\nTotal           $"<<Total/100<<"."<<(Total%100)/10<<"0";

//Ask for the amount paid
	cout<<"\n\nPaid Amount (dollar part) - [>=0]  :";
	cin>>PaidD;
	cout<<"Paid Amount (cents part)  - [0-90] :";
	cin>>PaidC;
	Paid    = PaidD * 100 + PaidC;
	Returns = Paid  - Total;

//Calculate the change
	OneC     = Returns ;
	HundredD = OneC     / 10000;
	OneC    -= HundredD * 10000;
	FiftyD   = OneC     /  5000;
	OneC    -= FiftyD   *  5000;
	TwentyD  = OneC     /  2000;
	OneC    -= TwentyD  *  2000;
	TenD     = OneC     /  1000;
	OneC    -= TenD     *  1000;

	FiveD    = OneC     /   500;
	OneC    -= FiveD    *   500;
	TwoD     = OneC     /   200;
	OneC    -= TwoD     *   200;
	OneD     = OneC     /   100;
	OneC    -= OneD     *   100;

	FiveC  = OneC   / 50;
	OneC  -= FiveC  * 50;
	TwoC   = OneC   / 20;
	OneC  -= TwoC   * 20;
	OneC  /= 10;

//Display the change
	cout<<"Change:         $"<<Returns/100<<"."<<(Returns%100)/10<<"0";
	cout<<"\n\n";
	cout<<  "        $100    :"<<HundredD<<endl;
	cout<<  "        $50     :"<<FiftyD  <<endl;
	cout<<  "        $20     :"<<TwentyD <<endl;
	cout<<  "        $10     :"<<TenD    <<endl;
	cout<<  "        $5      :"<<FiveD   <<endl;
	cout<<  "        $2      :"<<TwoD    <<endl;
	cout<<  "        $1      :"<<OneD    <<endl;
	cout<<  "        $0.5    :"<<FiveC   <<endl;
	cout<<  "        $0.2    :"<<TwoC    <<endl;
	cout<<  "        $0.1    :"<<OneC    ;

	return 0;
}
