//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 1-4
#include <iostream>
using namespace std;
#include "svg.h"

int main()
{
	//Face
	svgout<<"circle 200 200 200      0  blue  blue";
	svgout<<"circle 200 250 150      0 white white";
	//NoseLine
	svgout<<"line   200 200 200 350  5 black";
	//Eyes
	svgout<<"circle 250 150  50      2 black white";
	svgout<<"circle 250 150  10      0 black black";
	svgout<<"circle 150 150  50      2 black white";
	svgout<<"circle 150 150  10      0 black black";
	//Whisker
	svgout<<"line   250 250 350 230  5 black";
	svgout<<"line   250 280 350 280  5 black";
	svgout<<"line   250 310 350 330  5 black";
	svgout<<"line   150 250  50 230  5 black";
	svgout<<"line   150 280  50 280  5 black";
	svgout<<"line   150 310  50 330  5 black";
	//Nose
	svgout<<"circle 200 200  25      0 red    red";
	//Mouth
	svgout<<"sector 200 300 130 300 270 300 0 1 black red";

	return 0;
}
