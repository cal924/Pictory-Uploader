//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 6

#include <iostream>
using namespace std;
#include "svg.h"

//Function for drawing pattern1
void pattern1 (float x, float y, float size)
{
	svgout << "circle" << x << y << (size)         << "0 none blue" ;
	svgout << "circle" << x << y << (size * 3 / 4) << "0 none white";
	svgout << "circle" << x << y << (size / 2)     << "0 none blue" ;
	svgout << "circle" << x << y << (size / 4)     << "0 none white";
}

//Function for drawing pattern2
void pattern2 (float x, float y, float size)
{
	svgout << "circle" << x << y << (size)         << "0 none red"  ;
	svgout << "circle" << x << y << (size * 7 / 8) << "0 none white";
	svgout << "circle" << x << y << (size * 3 / 4) << "0 none red"  ;
	svgout << "circle" << x << y << (size / 2)     << "0 none white";
}

//Function for drawing pattern3
void pattern3 (float x, float y, float size)
{
	svgout << "circle" << x << y << (size)         << "0 none brown";
	svgout << "circle" << x << y << (size * 5 / 8) << "0 none white";
	svgout << "circle" << x << y << (size / 2)     << "0 none brown";
}

//Function for drawing pattern4
void pattern4 (float x, float y, float size)
{
	svgout << "circle" << x << y << (size)           << "0 none green";
	svgout << "circle" << x << y << (size * 29 / 30) << "0 none white";
	svgout << "circle" << x << y << (size * 2 / 3)   << "0 none green";
	svgout << "circle" << x << y << (size / 3)       << "0 none white";
}

//Function for drawing pattern5
void pattern5 (float x, float y, float size)
{
	svgout << "circle" << x << y << (size)         << "0 none magenta";
	svgout << "circle" << x << y << (size * 7 / 8) << "0 none white";
	svgout << "circle" << x << y << (size * 3 / 4) << "0 none magenta";
	svgout << "circle" << x << y << (size / 2)     << "0 none white";
}

//Function for drawing pattern6
void pattern6 (float x, float y, float size)
{
	svgout << "circle" << x << y << (size)           << "0 none yellow";
	svgout << "circle" << x << y << (size * 19 / 20) << "0 none white";
	svgout << "circle" << x << y << (size * 5 / 8)   << "0 none yellow";
}

//Function for selecting pattern
void drawpattern(float x, float y, float size, int patternID)
{
	switch (patternID)
	{
	case 1: pattern1(x, y, size); break;
	case 2: pattern2(x, y, size); break;
	case 3: pattern3(x, y, size); break;
	case 4: pattern4(x, y, size); break;
	case 5: pattern5(x, y, size); break;
	case 6: pattern6(x, y, size); break;
	}
}

void draw(float x, float y, float size, int depth)
{
	drawpattern(x, y, size, depth);
	if (depth - 1)
	{
		draw(x-size, y, size/2, depth-1);
		draw(x+size, y, size/2, depth-1);
		draw(x, y-size, size/2, depth-1);
		draw(x, y+size, size/2, depth-1);
	}
}

int main()
{
	int depth = 1;
	do
	{
		cout<<"Enter the depth: ";
		cin >>depth;
	} while ( (depth<1) || (depth>6) );
	draw(350, 350, 175, depth);
	return 0;
}
