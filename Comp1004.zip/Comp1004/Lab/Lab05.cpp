//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 5

#include <iostream>
using namespace std;
#include "svg.h"



//Function for drawing pattern1
void pattern1 (int x, int y, float size)
{
	svgout << "circle" << x << y << (size)         << "0 none blue" ;
	svgout << "circle" << x << y << (size * 3 / 4) << "0 none white";
	svgout << "circle" << x << y << (size / 2)     << "0 none blue" ;
	svgout << "circle" << x << y << (size / 4)     << "0 none white";
}

//Function for drawing pattern2
void pattern2 (int x, int y, float size)
{
	svgout << "circle" << x << y << (size)         << "0 none red"  ;
	svgout << "circle" << x << y << (size * 7 / 8) << "0 none white";
	svgout << "circle" << x << y << (size * 3 / 4) << "0 none red"  ;
	svgout << "circle" << x << y << (size / 2)     << "0 none white";
}

//Function for drawing pattern3
void pattern3 (int x, int y, float size)
{
	svgout << "circle" << x << y << (size)         << "0 none brown";
	svgout << "circle" << x << y << (size * 5 / 8) << "0 none white";
	svgout << "circle" << x << y << (size / 2)     << "0 none brown";
}

//Function for drawing pattern4
void pattern4 (int x, int y, float size)
{
	svgout << "circle" << x << y << (size)           << "0 none green";
	svgout << "circle" << x << y << (size * 29 / 30) << "0 none white";
	svgout << "circle" << x << y << (size * 2 / 3)   << "0 none green";
	svgout << "circle" << x << y << (size / 3)       << "0 none white";
}

//Function for drawing pattern5
void pattern5 (int x, int y, float size)
{
	svgout << "circle" << x << y << (size)         << "0 none magenta";
	svgout << "circle" << x << y << (size * 7 / 8) << "0 none white";
	svgout << "circle" << x << y << (size * 3 / 4) << "0 none magenta";
	svgout << "circle" << x << y << (size / 2)     << "0 none white";
}

//Function for drawing pattern6
void pattern6 (int x, int y, float size)
{
	svgout << "circle" << x << y << (size)           << "0 none yellow";
	svgout << "circle" << x << y << (size * 19 / 20) << "0 none white";
	svgout << "circle" << x << y << (size * 5 / 8)   << "0 none yellow";
}


int main()
{
	const int CircleMax = 100,
			  margin    = 600;

	int x[CircleMax],
		y[CircleMax];
	float size[CircleMax];
	int patternID[CircleMax];
	int CircleNum,
		command;

	//Input Number of Circles
	cout<<"Enter the number of circles (1-"<<CircleMax<<"): ";
	cin >>CircleNum;
	while ( (CircleNum<=0) || (CircleNum>CircleMax) )
	{
		cerr<<"The number of circles should be between 1 to "<<CircleMax<<endl;
		cout<<"Enter the number of circles (1-"<<CircleMax<<"): ";
		cin >>CircleNum;
	}

	//Initialization
	for (int i=0 ; i < CircleNum ; i++)
	{
		x[i]         = 300;
		y[i]         = 300;
		size[i]      =  10.0;
		patternID[i] =   1;
	}

	do
	{
		//Print Menu
		cout<<"\n===== Menu ====="<<endl;
		cout<<"** Please refresh the web browser after the Draw operation **"<<endl;
		cout<<"0 : Exit"<<endl;
		cout<<"1 : Draw"<<endl;
		cout<<"2 : Modify the position of the ith circle"<<endl;
		cout<<"3 : Modify the radius of the ith circle"<<endl;
		cout<<"4 : Modify the pattern of the ith circle"<<endl;
		//Input Command
		cout<<"\nEnter your command (0-4): ";
		cin >>command;
		while ( (command<0) || (command>4) )
		{
			cerr<<"The command should be between 0 to 4"<<endl;
			cout<<"Enter your command (0-4): ";
			cin >>command;
		}
		//Manipulate Command
		switch (command)
		{
		case 1: //Draw
			{
				for( int i=0 ; i<CircleNum ; i++)
				{
					switch (patternID[i])
					{
					case 1 : pattern1(x[i], y[i], size[i]); break;
					case 2 : pattern2(x[i], y[i], size[i]); break;
					case 3 : pattern3(x[i], y[i], size[i]); break;
					case 4 : pattern4(x[i], y[i], size[i]); break;
					case 5 : pattern5(x[i], y[i], size[i]); break;
					case 6 : pattern6(x[i], y[i], size[i]); break;
					default: return -1;
					}
				}

				break;
			}
		case 2: //Modify the position of the ith circle
			{
				int i = 0;
				cout<<"=== Modify the position of a circle ==="<<endl;

				cout<<"Enter the circle index (0 - "<<CircleNum-1<<"): ";
				cin >> i;
				while ( ( i < 0 ) || ( i > (CircleNum-1) ) )
				{
					cerr<<"The circle index should be between 0 and "<<CircleNum-1<<endl;
					cout<<"Enter the circle index (0 - "<<CircleNum-1<<"): ";
					cin >> i;
				}

				cout<<"The current circle position is ("<<x[i]<<","<<y[i]<<")"<<endl;

				cout<<"Enter the x-coordinates: ";
				cin>>x[i];
				while ( (x[i] < 0) || (x[i] > margin) )
				{
					cerr<<"The valid range of the x-coordinate is 0 - "<<margin<<endl;
					cout<<"Enter the x-coordinates: ";
					cin >>x[i];
				}

				cout<<"Enter the y-coordinates: ";
				cin>>y[i];
				while ( (y[i] < 0) || (y[i] > margin) )
				{
					cerr<<"The valid range of the y-coordinate is 0 - "<<margin<<endl;
					cout<<"Enter the y-coordinates: ";
					cin>>y[i];
				}

				break;
			}
		case 3: //Modify the radius of the ith circle
			{
				int i = 0;
				cout<<"=== Modify the radius of a circle ==="<<endl;

				cout<<"Enter the circle index (0 - "<<CircleNum-1<<"): ";
				cin >> i;
				while ( ( i < 0 ) || ( i > (CircleNum-1) ) )
				{
					cerr<<"The circle index should be between 0 and "<<CircleNum-1<<endl;
					cout<<"Enter the circle index (0 - "<<CircleNum-1<<"): ";
					cin >> i;
				}

				cout<<"The current radius is "<<size[i]<<endl;

				cout<<"Enter the radius (10.0 to 100.0): ";
				cin >>size[i];
				while ( (size[i] < 10.0) || (size[i] > 100.0) )
				{
					cerr<<"The valid length of the radii: 10 - 100 pixels"<<endl;
					cout<<"Enter the radius (10.0 to 100.0): ";
					cin >>size[i];
				}

				break;
			}
		case 4: //Modify the pattern of the ith circle
			{
				int i = 0;
				cout<<"=== Modify the pattern of a circle ==="<<endl;

				cout<<"Enter the circle index (0 - "<<CircleNum-1<<"): ";
				cin >> i;
				while ( ( i < 0 ) || ( i > (CircleNum-1) ) )
				{
					cerr<<"The circle index should be between 0 and "<<CircleNum-1<<endl;
					cout<<"Enter the circle index (0 - "<<CircleNum-1<<"): ";
					cin >> i;
				}

				cout<<"The current pattern ID is "<<patternID[i]<<endl;

				cout<<"Enter the pattern ID (1-6): ";
				cin >>patternID[i];
				while ( (patternID[i] < 1) || (patternID[i] > 6) )
				{
					cerr<<"The number of pattern: Pattern 1 to 6";
					cout<<"Enter the pattern ID (1-6): ";
					cin >>patternID[i];
				}

				break;
			}
		default:
			return -1;
		}

	}	while (command);

	return 0;
}



