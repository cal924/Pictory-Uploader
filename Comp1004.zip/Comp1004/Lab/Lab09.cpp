//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 9

#include<iostream>
using namespace std;

const int MaxLen = 10;
const int MaxLec = 100;

struct Time
{
	int hour;
	int min;
};

struct Lecture
{
	char Name[MaxLen];
	char Section[MaxLen];
	char Day[2];
	Time BegTime;
	Time EndTime;
};

Lecture Lesson[MaxLec];
int numEvent;

int Collision(const Lecture Temp)
{
	int NewBeg = Temp.BegTime.hour * 60 + Temp.BegTime.min;
	int NewEnd = Temp.EndTime.hour * 60 + Temp.EndTime.min;
	for (int i = 0; i < numEvent; i++)
		if ( (Temp.Day[0] == Lesson[i].Day[0]) && (Temp.Day[1] == Lesson[i].Day[1]) )
		{
			int Beg = Lesson[i].BegTime.hour * 60 + Lesson[i].BegTime.min;
			int End = Lesson[i].EndTime.hour * 60 + Lesson[i].EndTime.min;
			if ( ( (NewBeg >= Beg)&&(NewBeg < End) ) || ( (NewEnd > Beg)&&(NewEnd <= End) ) )
				return i;
		}
	return -1;
}

void PrintMenu(int& command)
{
	cout<<"=== A simple C++ course planner ==="<<endl;
	cout<<"0: Exit the program"<<endl;
	cout<<"1: Add a calendar event"<<endl;
	cout<<"2: Print all the events (the order is not important)"<<endl;
	cout<<"Command: ";
	cin >>command;
}

void DisplayLesson(const Lecture L)
{
	cout<< L.Name << '(' << L.Section << ") - " << L.Day << ' ';
	cout<< L.BegTime.hour/10 << L.BegTime.hour%10 << ':' << L.BegTime.min/10 << L.BegTime.min%10 << " to ";
	cout<< L.EndTime.hour/10 << L.EndTime.hour%10 << ':' << L.EndTime.min/10 << L.EndTime.min%10 << endl;
}

void AddEvent(Lecture Lesson[])
{
	Lecture Temp;
	cout<<"Enter the course code (e.g. COMP1004): ";
	cin >>Temp.Name;
	cout<<"Enter the section code (e.g. LA1A): ";
	cin >>Temp.Section;
	cout<<"Enter the weekday (Mo/Tu/We/Th/Fr):";
	cin >>Temp.Day;
	cout<<"Enter the start hour (9-18): ";
	cin >>Temp.BegTime.hour;
	cout<<"Enter the start minute (0-59):";
	cin >>Temp.BegTime.min;
	cout<<"Enter the end hour (9-18): ";
	cin >>Temp.EndTime.hour;
	cout<<"Enter the end minute (0-59): ";
	cin >>Temp.EndTime.min;

	int EventCollide = Collision(Temp);
	if ( EventCollide == -1 )
	{
		Lesson[numEvent++] = Temp;
		cout<<numEvent;
	}
	else
	{
		cout<<"Time conflict with ";
		DisplayLesson(Lesson[EventCollide]);
	}

}

void PrintEvent(Lecture Lesson[])
{
	cout<<"=== All the events ==="<<endl;
	for (int i = 0 ; i < numEvent; i++)
	{
		cout << i+1 << " : ";
		DisplayLesson(Lesson[i]);
	}
}

int main(void)
{
	int command = 0 ;

	do
	{
		PrintMenu(command);
		switch(command)
		{
		case 1 : AddEvent(Lesson)  ; break;
		case 2 : PrintEvent(Lesson); break;
		}
	} while (command !=0);

	return 0;
}
