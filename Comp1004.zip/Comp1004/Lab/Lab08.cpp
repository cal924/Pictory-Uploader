//NAME: Tam Siu Lun
//ID:20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Lab 8

/*
 * Lab 8  Parsing arithmetic expression with a recursive approach
 *        To tokenize the string input, you may refer to the sample code of Lab 7
 *        To evaluate an expression, you have to recursively break down the expression into
 *        smaller components (i.e., smaller expressions, terms, or factors)
 *        The composition of the expressions, terms, and factors is defined by a set of
 *        grammar rules. You may refer to the lab page for details.
 */

#include <iostream>
#include <cctype>
#include <cstring>
using namespace std;

const int MAX_NUM_TOKEN = 300 ;	// Maximum number of words
const int MAX_TOKEN_LEN = 20  ;	// Maximum length of a word
const int MAX_LINE_LEN  = 1024;	// Maximum length of input string

/*
 * TODO: Declare the functions: eval_expression, eval_term, eval_factor, here
 */
int eval_expression(const char words[][MAX_TOKEN_LEN], int& current_token);
int eval_term      (const char words[][MAX_TOKEN_LEN], int& current_token);
int eval_factor    (const char words[][MAX_TOKEN_LEN], int& current_token);

/*
 *  To retrieve input from the user
 */
void get_input(char input[])
{
	cout << "Enter an arithmetic expression: ";
	cin.getline( input, MAX_LINE_LEN+1, '\n');

    int length = strlen(input);

    /*
     * Add a space to ease tokenize_input().
     * That is, there is always a space after a token
     */
    input[length] = ' ';
    input[length+1] = '\0';
}

int strToInt(const char str[])
{
	/*
	 * TODO: convert the str[] into an integer and return the value
	 */
	int length = strlen(str);
	int number = 0;
	for (int i=0 ; i< length ; i++)
		number = number * 10 + ( str[i] - '0');
	return number;
}

/*
 * To convert the input string into tokens and put them into the token array
 */
void tokenize_input(char words[][MAX_TOKEN_LEN], const char input[], int& num_tokens)
{
    // TODO
	int i = 0,
		j = 0;
	num_tokens = 0;
	while (true)
	{
		while (input[i] == ' ')
			++i;
		if (input[i] == '\0')
			break;
		j = 0;
		while (input[i] != '\0' && input[i] != ' ')
			words[num_tokens][j++] = input[i++];
		words[num_tokens++][j] = '\0';
	}
}



/*
 * To evaluate an expression E.
 * An expression E can be resolved as E + T  or E - T or simply T.
 * i.e.,   E -> E+T | E-T | T
 * Hint: To identify the 3 possible cases, try to find T by calling eval_term()
 *       and then check if there is + / - and resolve E if any
 */
int eval_expression(const char words[][MAX_TOKEN_LEN], int& current_token)
{
	int term_value = eval_term(words, current_token);

    if (current_token == 0)
        return term_value;

    switch (words[--current_token][0])
    {
        case '+': return eval_expression(words, --current_token) + term_value;
        case '-': return eval_expression(words, --current_token) - term_value;
        default : return term_value;
	}
}

/*
 * evaluate a term T
 * an term T can be resolved as T * F  or T / F or simply F
 * i.e.,   T -> T*F | T/F | F
 * Hint: To identify the 3 possible cases, try to find F by calling eval_factor()
 *       and then check if there is * or / and resolve T if any
 */
int eval_term(const char words[][MAX_TOKEN_LEN], int& current_token)
{
    // TODO
	int factor_value = eval_factor(words, current_token);

	if (current_token == 0)
		return factor_value;

	switch (words[--current_token][0])
	{
	case '*' : return (eval_term(words, --current_token) * factor_value);
	case '/' : return (eval_term(words, --current_token) / factor_value);
	default  : ++current_token; return factor_value;
	}
}

/*
 * To evaluate a factor F
 * A factor F can be resolved as ( E ) or n , where n is an integer value
 * i.e.,	F -> (E) | n
 * Hint: To identify the 2 possible cases, try to check if the current token is an
 * 		 integer. If no, you have to further check there are any parentheses and
 * 		 evaluate the expression within the paretheses by calling eval_expression()
 */
int eval_factor(const char words[][MAX_TOKEN_LEN], int& current_token)
{
    // TODO
	if ( isdigit(words[current_token][0]) )
		return strToInt(words[current_token]);
	else if ( words[current_token][0] == ')' )
		return eval_expression(words , --current_token);
	else
		exit(-1);
}



int main()
{
    char input[MAX_LINE_LEN+1];		// array holding the user input
    char words[MAX_NUM_TOKEN][MAX_TOKEN_LEN];	// array holding the tokens in user input
    int num_tokens = 0;

	get_input(input);
	tokenize_input(words, input, num_tokens);

    // index to the next token to be read (reading from the last to the first token)
    int current_token = num_tokens - 1;
	cout << "Result:\t" << eval_expression(words, current_token) << endl;
	return 0;
}
