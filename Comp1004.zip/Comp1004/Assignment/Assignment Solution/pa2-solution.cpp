#include <iostream>
using namespace std;
#include "svg.h"

// Definitions of various constants
enum output_mode { CHAR, BASIC_SVG, ADV_SVG };

const char COLON = ':';
const char SPACE = ' ';

const int MAX_WIDTH = 8;
const int MAX_WORD_LEN = 20;
const int BASIC_WIDTH = 30;
const int BASIC_BORDER = 1;
const int ADV_WIDTH = 20;
const int ADV_BORDER = 2;
const int NO_EMPTY_CELL = -1;

// Definitions of various global variables
char draw_letter = 'A'; // Start to draw character blocks with 'A'
int c_code = 0; // Index of the drawing color. Start from 0 which is aqua
char cell[MAX_WIDTH][MAX_WIDTH]; // Board of largest size to hold the L-blocks
char color[][MAX_WORD_LEN] = 
{
    "aqua",
    "blue",
    "fuchsia",
    "gray",
    "green",
    "lime",
    "maroon",
    "navy",
    "olive",
    "purple",
    "red",
    "silver",
    "teal",
    "yellow",
    "antiquewhite",
    "aquamarine",
    "bisque",
    "blueviolet",
    "brown",
    "burlywood",
    "cadetblue"
};


/*
 * Find out which quadrant the empty cell belongs to.
 * The quadrant is labelled as 1 2
 *                             3 4
 */

int which_quadrant(int width, int empty_cell_x, int empty_cell_y)
{
    int quadrant_width = width/2;
    return (empty_cell_y/quadrant_width << 1) + empty_cell_x/quadrant_width + 1;
}


/*
 * Used by console output (mode 0).
 * Since the L-blocks are already represented by characters in the 2D char
 * array "cell", just print out the 2D array row-by-row.
 */

void char_draw_board(int width)
{
    int i, j;

    // First print the column labels
    cout << SPACE << SPACE;
    for (j = 0; j < width; ++j)
        cout << j << SPACE;
    cout << endl;
    
    // Then print the blocks row-by-row with row labels
    for (i = 0; i < width; ++i)
    {
        cout << i << COLON;
        for (j = 0; j < width; ++j)
            cout << cell[j][i] << SPACE;
        cout << endl;
    }
}
        
/*
 * Draw an SVG rectnagle with a cross inside. Its size is the same as that of one cell.
 * This cell is located at (x,y).
 */

void svg_rect_and_cross(int x, int y, int width, int thickness)
{
    svg_rect(x*width, y*width, width, width, thickness, "black", "white");
    svg_line(x*width, y*width, (x+1)*width, (y+1)*width, thickness, "black");
    svg_line((x+1)*width, y*width, x*width, (y+1)*width, thickness, "black");
}

        
/*
 * Start from the 2D char array which contains the L-blocks represented by
 * different letters. Just map each character to a rectangle of different colors;
 * one color for one character, starting from color[0].
 *
 * Note that 'A' is mapped to color[0], 'B' to color[1], etc. So an easy way to
 * get the mapping color index is (color_letter - 'A').
 */

void basic_svg_draw_board(int width, int cell_width, int border_thickness)
{
    for (int i = 0; i < width; ++i)
        for (int j = 0; j < width; ++j)
        {
            char cell_letter = cell[j][i];
            
            if (cell_letter != SPACE)
                svg_rect(j*cell_width, i*cell_width, cell_width, cell_width, 
                         border_thickness, "black", color[cell_letter-'A']);
            else // Draw a rectangular cell with a cross inside
                svg_rect_and_cross(j, i, cell_width, border_thickness);
        }
}

// It sets a square with size 2x2 cells in the global "cell" char array with the current letter.
// The upper left corner of this square is at coordinates (x,y)

void char_square(int x, int y)
{
	cell[x][y] 
	= cell[x][y+1]
	= cell[x+1][y]
	= cell[x+1][y+1]
	= draw_letter++;
}

/*
 * For output modes 0 and 1.
 *
 * It creates the L-shaped blocks in the global "cell" char array.
 *
 * Formal parameters:
 *		width: width of the the board
 *		(x0, y0): actual coordinates of the top left corner of the board
 *		(empty_cell_x, empty_cell_y): coordinates of the empty cell w.r.t. (x0, y0)
 *		real_empty_cell: Is the empty cell real or virtual (check out the algorithm
 *			explanation in "lshape_explain.pdf")?
 */

void char_blocks(int width, int x0, int y0, int empty_cell_x, int empty_cell_y, 
				bool real_empty_cell=false)
{
    if (width == 2) // Base case when the board size is 2 x 2
    {
        /* 
         * Trick #1: First fill all the 4 cells with the drawing color. 
         * The empty cell will be overwritten correctly by a later call.
         */
        
		char_square(x0,y0);
		
        if (real_empty_cell) // Draw the empty cell
            cell[x0+empty_cell_x][y0+empty_cell_y] = SPACE;
		
		return;
		
    }
	
    // Find the quadrant where the empty cell lies in
    int empty_cell_quadrant = which_quadrant(width, empty_cell_x, empty_cell_y);
	
    int half_width  = width/2;
    int virtual_empty_cell_offset = half_width - 1;
	
    // (x1, y1) is the middle point of the board
    int x1 = x0 + half_width;
    int y1 = y0 + half_width;
	
	/* 
	* Trick #2: There are four recursive calls involved. The idea is to execute first
	* the three that correspond to the quadrants not containing the empty cell. Their calls properly
	* "draw" (in the "cell" array) the underlying L-blocks for their part of the board. Then print a 
	* 2x2 square in the middle of the board. This square will go on top of the previously drawn 
	* L-blocks. Finally, execute the last recursive call for the quadrant that contains the empty cell. 
	* Notice that one corner/cell of the middle 2x2 square will be overwritten, nicely producing an 
	* L-block shape in the middle of the board, as suggested in "lshape_explain.pdf".
	*/
	
    switch (empty_cell_quadrant)
    {
        case 1:
			char_blocks(half_width, x1, y0, 0, virtual_empty_cell_offset);
			char_blocks(half_width, x0, y1, virtual_empty_cell_offset, 0);
			char_blocks(half_width, x1, y1, 0, 0);
			char_square(x1-1, y1-1);
			char_blocks(half_width, x0, y0, empty_cell_x, empty_cell_y, true);
			
			break;
			
        case 2:
			char_blocks(half_width, x0, y0, 
					   virtual_empty_cell_offset, virtual_empty_cell_offset);
			char_blocks(half_width, x0, y1, virtual_empty_cell_offset, 0);
			char_blocks(half_width, x1, y1, 0, 0);
			char_square(x1-1, y1-1);
			char_blocks(half_width, x1, y0, 
					   empty_cell_x-half_width, empty_cell_y, true);
			break;
			
        case 3:
			char_blocks(half_width, x0, y0, 
					   virtual_empty_cell_offset, virtual_empty_cell_offset);
			char_blocks(half_width, x1, y0, 0, virtual_empty_cell_offset);
			char_blocks(half_width, x1, y1, 0, 0);
			char_square(x1-1, y1-1);
			char_blocks(half_width, x0, y1, 
					   empty_cell_x, empty_cell_y-half_width, true);
			break;
			
        case 4:
			char_blocks(half_width, x0, y0, 
					   virtual_empty_cell_offset, virtual_empty_cell_offset);
			char_blocks(half_width, x1, y0, 0, virtual_empty_cell_offset);
			char_blocks(half_width, x0, y1, virtual_empty_cell_offset, 0);
			char_square(x1-1, y1-1);
			char_blocks(half_width, x1, y1, empty_cell_x-half_width, 
					   empty_cell_y-half_width, true);
			break;
			
        default:
            cerr << "Error: Wrong quadrant " << empty_cell_quadrant << endl;
            exit(-1);
    }
	
}
        
/*
 * For output mode 2.
 * It is very similar to char_blocks(), with the difference that it prints SVG rectangles
 * in "output.svg" directly, instead of just setting them in array "cell".
 */

void adv_svg_blocks(int width, int x0, int y0, int empty_cell_x, int empty_cell_y, 
               bool real_empty_cell=false)
{
    if (width == 2) // Base case when the board size is 2 x 2
    {
        /* 
         * Trick #1: First fill all the 4 cells with the drawing color. 
         * The empty cell will be overwritten correctly by a later call.
         */
        svg_rect(x0*ADV_WIDTH, y0*ADV_WIDTH, 2*ADV_WIDTH, 2*ADV_WIDTH, 
                 ADV_BORDER, "black", color[c_code++]);

        if (real_empty_cell) // Draw a white rectangle with a cross
            svg_rect_and_cross(x0+empty_cell_x, y0+empty_cell_y, 
                               ADV_WIDTH, ADV_BORDER);
		
		return;

    }

    // Find the quadrant where the empty cell lies in
    int empty_cell_quadrant = which_quadrant(width, empty_cell_x, empty_cell_y);

    int half_width  = width/2;
    int virtual_empty_cell_offset = half_width - 1;

    // (x1, y1) is the middle point of the board
    int x1 = x0 + half_width;
    int y1 = y0 + half_width;

	/* 
	 * Trick #2: There are four recursive calls involved. The idea is to execute first
	 * the three that correspond to the quadrants not containing the empty cell. Their calls properly
	 * (and directly) draw in "output.svg" the underlying L-blocks for their part of the board. Then print a 
	 * 2x2 square in the middle of the board. This square will go on top of the previously drawn 
	 * L-blocks. Finally, execute the last recursive call for the quadrant that contains the empty cell. 
	 * Notice that one corner/cell of the middle 2x2 square will be overwritten, nicely producing an 
	 * L-block shape in the middle of the board, as suggested in "lshape_explain.pdf".
	 */

    switch (empty_cell_quadrant)
    {
        case 1:
				adv_svg_blocks(half_width, x1, y0, 0, virtual_empty_cell_offset);
				adv_svg_blocks(half_width, x0, y1, virtual_empty_cell_offset, 0);
                adv_svg_blocks(half_width, x1, y1, 0, 0);
				svg_rect((x1-1)*ADV_WIDTH, (y1-1)*ADV_WIDTH, 2*ADV_WIDTH, 2*ADV_WIDTH, 
			                 ADV_BORDER, "black", color[c_code++]);
				adv_svg_blocks(half_width, x0, y0, empty_cell_x, empty_cell_y, true);
			
            	break;

        case 2:
                adv_svg_blocks(half_width, x0, y0, 
						   virtual_empty_cell_offset, virtual_empty_cell_offset);
				adv_svg_blocks(half_width, x0, y1, virtual_empty_cell_offset, 0);
                adv_svg_blocks(half_width, x1, y1, 0, 0);
				svg_rect((x1-1)*ADV_WIDTH, (y1-1)*ADV_WIDTH, 2*ADV_WIDTH, 2*ADV_WIDTH, 
				                 ADV_BORDER, "black", color[c_code++]);
				adv_svg_blocks(half_width, x1, y0, 
								empty_cell_x-half_width, empty_cell_y, true);
            	break;

        case 3:
           		adv_svg_blocks(half_width, x0, y0, 
						   virtual_empty_cell_offset, virtual_empty_cell_offset);
				adv_svg_blocks(half_width, x1, y0, 0, virtual_empty_cell_offset);
                adv_svg_blocks(half_width, x1, y1, 0, 0);
				svg_rect((x1-1)*ADV_WIDTH, (y1-1)*ADV_WIDTH, 2*ADV_WIDTH, 2*ADV_WIDTH, 
				                 ADV_BORDER, "black", color[c_code++]);
				adv_svg_blocks(half_width, x0, y1, 
								empty_cell_x, empty_cell_y-half_width, true);
				break;

        case 4:
           		adv_svg_blocks(half_width, x0, y0, 
						   virtual_empty_cell_offset, virtual_empty_cell_offset);
				adv_svg_blocks(half_width, x1, y0, 0, virtual_empty_cell_offset);
				adv_svg_blocks(half_width, x0, y1, virtual_empty_cell_offset, 0);
				svg_rect((x1-1)*ADV_WIDTH, (y1-1)*ADV_WIDTH, 2*ADV_WIDTH, 2*ADV_WIDTH, 
			                 ADV_BORDER, "black", color[c_code++]);
				adv_svg_blocks(half_width, x1, y1, empty_cell_x-half_width, 
		                             empty_cell_y-half_width, true);
            	break;

        default:
            cerr << "Error: Wrong quadrant " << empty_cell_quadrant << endl;
            exit(-1);
    }

}

int main()
{
    int width; // Width of the board; must be 2, 4 or 8
    int empty_cell_x; // x-coordinate of the empty cell
    int empty_cell_y; // y-coordinate of the empty cell
    int output_mode;  // Output mode    
    
    // Get inputs
    cout << "Enter the width/height of the puzzle (2, 4, 8): ";
    cin >> width;
    cout << "Enter the x-coordinate of the empty cell (0-" << width-1 <<"):  ";
    cin >> empty_cell_x;
    cout << "Enter the y-coordinate of the empty cell (0-" << width-1 <<"):  ";
    cin >> empty_cell_y;
    cout << "(0: Console output, 1: Basic SVG output, 2: advanced SVG output)"
         << endl << "Enter the output mode:  ";
    cin >> output_mode; 

	switch (output_mode)
    {
		// Console output
		case 0: char_blocks(width, 0, 0, empty_cell_x, empty_cell_y, true);
			char_draw_board(width); 
			break;

		// Basic SVG output
		case 1: char_blocks(width, 0, 0, empty_cell_x, empty_cell_y, true);
			basic_svg_draw_board(width, BASIC_WIDTH, BASIC_BORDER); 
			break;

		// Advanced SVG output
		case 2: 
			adv_svg_blocks(width, 0, 0, empty_cell_x, empty_cell_y, true);
			break;

		default: cerr << "Error: Wrong output mode: " << output_mode << endl;
			return -1;
	}

    return 0;
}
