/ NAME:
// ID:
// EMAIL:
// Lab Section:

#include <iostream>
using namespace std;


/* 
 * The following C++ function implements the mathematical function f(n) included 
 * in the description of the assignment.
 */

int f(int n)
{
    if (n % 2)
        return n * 3 + 1;
    else
        return n / 2;
}   



/*
 * Main function
 */

int main()
{
    int s, e;                                   // the input range is [s,e]
    
    cout << "Enter s (for start): "; 
    cin >> s;                                   // Receive the input from the user
    cout << "Enter e (for end): "; 
    cin >> e;
    
    int element;                                // A sequence element
    int length;                                 // Length of the sequence at a certain iteration

    // Max sequence length over all iterations so far (initialization is important)
    int best_length = 1;                        
    // The n investigated at a certain iteration (initialized to s)
    int n = s;                                  
    // The n that leads to the max sequence length over all iterations so far. 
    // Initialization is important.
    int best_n = s;                             

    while(n <= e)                               // Checks every possible n in [s,e]
    {
        // Important initiallization before starting a new sequence
        length = 1;                             
        // Initialize the first sequence element to the current n
        element = n;                            

        // It produces the sequence elements until some element becomes 1.
        while ( element != 1 )                  
        {
            element = f(element);               // Produce the next element 
            ++length;                           // Increase the length whenever 
                                                // we produce a new element
        }

        // If the length of this sequence is larger than the maximum so far
        if (best_length < length)               
        {
            best_length = length;               // Update the best length
            best_n = n;                         // Update the best n
        }

        // Increase n by one, so that the while loop explores the next n in [s,e]
        ++n;                                    
    }

    // Print the output on the screen
    cout << "n: " << best_n << ", length: " << best_length << endl;
    
    return 0;
}
