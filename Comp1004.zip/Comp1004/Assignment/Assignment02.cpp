//NAME: Tam Siu Lun
//ID: 20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Assignment 2

#include<iostream>
using namespace std;
#include"svg.h"

const int MaxN = 8;
char Alphabet = 'A' - 1;
char cell[MaxN][MaxN];

void Color(char a)
{
	//TODO Display the color base on the character
	switch (a%21)
	{
	case  0 : svgout<<"aqua"        ; break;
	case  1 : svgout<<"blue"        ; break;
	case  2 : svgout<<"fuchsia"     ; break;
	case  3 : svgout<<"gray"        ; break;
	case  4 : svgout<<"green"       ; break;
	case  5 : svgout<<"lime"        ; break;
	case  6 : svgout<<"maroon"      ; break;
	case  7 : svgout<<"navy"        ; break;
	case  8 : svgout<<"olive"       ; break;
	case  9 : svgout<<"purple"      ; break;
	case 10 : svgout<<"red"         ; break;
	case 11 : svgout<<"silver"      ; break;
	case 12 : svgout<<"teal"        ; break;
	case 13 : svgout<<"yellow"      ; break;
	case 14 : svgout<<"antiquewhite"; break;
	case 15 : svgout<<"aquamarine"  ; break;
	case 16 : svgout<<"bisque"      ; break;
	case 17 : svgout<<"blueviolet"  ; break;
	case 18 : svgout<<"brown"       ; break;
	case 19 : svgout<<"burlywood"   ; break;
	case 20 : svgout<<"cadetblue"   ; break;
	default : cerr<<"ERROR!! Color not found"<<endl;
	}
}

void PrintArray(int StartX, int StartY, int Size, int EmptyX, int EmptyY)
{
	//TODO Fill in the middle part of the array and then recursion
	Alphabet++;
	int MiddleX = StartX + Size/2,
		MiddleY = StartY + Size/2;

	if (EmptyX < MiddleX)
	{//Left
		if (EmptyY < MiddleY)
		{//Top Left
			cell[MiddleX  ][MiddleY  ] = Alphabet;
			cell[MiddleX  ][MiddleY-1] = Alphabet;
			cell[MiddleX-1][MiddleY  ] = Alphabet;
			if (Size !=2)
			{
				PrintArray(StartX  , StartY  , Size/2 , EmptyX    , EmptyY   );
				PrintArray(StartX  , MiddleY , Size/2 , MiddleX-1 , MiddleY  );
				PrintArray(MiddleX , StartY  , Size/2 , MiddleX   , MiddleY-1);
				PrintArray(MiddleX , MiddleY , Size/2 , MiddleX   , MiddleY  );
			}
		}
		else
		{//Bottom Left
			cell[MiddleX  ][MiddleY  ] = Alphabet;
			cell[MiddleX  ][MiddleY-1] = Alphabet;
			cell[MiddleX-1][MiddleY-1] = Alphabet;
			if (Size !=2)
			{
				PrintArray(StartX  , StartY  , Size/2, MiddleX-1 , MiddleY-1);
				PrintArray(StartX  , MiddleY , Size/2, EmptyX    , EmptyY   );
				PrintArray(MiddleX , StartY  , Size/2, MiddleX   , MiddleY-1);
				PrintArray(MiddleX , MiddleY , Size/2, MiddleX   , MiddleY  );
			}
		}
	}
	else
	{//Right
		if (EmptyY < MiddleY)
		{//Top Right
			cell[MiddleX-1][MiddleY-1] = Alphabet;
			cell[MiddleX-1][MiddleY  ] = Alphabet;
			cell[MiddleX  ][MiddleY  ] = Alphabet;
			if (Size !=2)
			{
				PrintArray(StartX  , StartY  , Size/2 , MiddleX-1 , MiddleY-1);
				PrintArray(StartX  , MiddleY , Size/2 , MiddleX-1 , MiddleY  );
				PrintArray(MiddleX , StartY  , Size/2 , EmptyX    , EmptyY   );
				PrintArray(MiddleX , MiddleY , Size/2 , MiddleX   , MiddleY  );
			}
		}
		else
		{//Bottom Right
			cell[MiddleX-1][MiddleY  ] = Alphabet;
			cell[MiddleX-1][MiddleY-1] = Alphabet;
			cell[MiddleX  ][MiddleY-1] = Alphabet;
			if (Size !=2)
			{
				PrintArray(StartX  , StartY  , Size/2 , MiddleX-1 , MiddleY-1);
				PrintArray(StartX  , MiddleY , Size/2 , MiddleX-1 , MiddleY  );
				PrintArray(MiddleX , StartY  , Size/2 , MiddleX   , MiddleY-1);
				PrintArray(MiddleX , MiddleY , Size/2 , EmptyX    , EmptyY   );
			}
		}
	}
}

void Output0(int Size)
{
	//TODO Output Mode 0 (Console Output)
	cout<<"  ";
	for ( int i=0; i<Size; i++ )
		cout<<i<<' ';
	for ( int i=0; i<Size; i++ )
	{
		cout<<'\n'<<i<<':';
		for ( int j=0; j<Size; j++ )
			cout<<cell[j][i]<<' ';
	}
}

void Output1(int Size)
{
	//TODO Output Mode 1 (Basic SVG Output)
	const int Width = 30;
	for (int i=0; i<Size; i++)
		for (int j=0; j<Size; j++)
		{
			svgout << "rect" << Width*i << Width*j << Width << Width << 1 << "black";
			if (cell[i][j] != ' ') //Fill the color
				Color(cell[i][j]);
			else
			{
				//Display a cross
				svgout << "none";
				svgout << "line" << Width*i     << Width*j << Width*(i+1) << Width*(j+1) << 1 << "black";
				svgout << "line" << Width*(i+1) << Width*j << Width*i     << Width*(j+1) << 1 << "black";
			}
		}
}

void Output2(int Size)
{	//TODO Output Mode 2 (Advanced SVG Output)
	//Fill the grids
	const int Width = 20;
	for (int i=0; i<Size; i++)
		for (int j=0; j<Size; j++)
		{
			svgout << "rect" << Width*i+10 << Width*j+10 << Width << Width << 0 << "none";
			if (cell[i][j] != ' ')
				Color(cell[i][j]);
			else
			{
				svgout << "none";
				svgout << "line" << Width*i+10     << Width*j+10   << Width*(i+1)+10 << Width*(j+1)+10 << 2 << "black";
				svgout << "line" << Width*(i+1)+10 << Width*j+10   << Width*i+10     << Width*(j+1)+10 << 2 << "black";
			}
		}
	svgout << "line" << 10 			  << 10 		   << 10	 		<< Width*Size+10 << 2 << "black";
	svgout << "line" << 10 			  << 10			   << Width*Size+10 << 10	  		 << 2 << "black";
	svgout << "line" << 10		 	  << Width*Size+10 << Width*Size+10 << Width*Size+10 << 2 << "black";
	svgout << "line" << Width*Size+10 << 10 	  	   << Width*Size+10 << Width*Size+10 << 2 << "black";
	//Draw the borders
	for (int i=0; i<Size; i++)
		for (int j=0; j<Size-1; j++)
		{
			if ( cell[i][j] != cell[i][j+1] )
				svgout << "line" << Width*i+10     << Width*(j+1)+10 << Width*(i+1)+10 << Width*(j+1)+10 << 2 << "black";
			if ( cell[j][i] != cell[j+1][i] )
				svgout << "line" << Width*(j+1)+10 << Width*i+10     << Width*(j+1)+10 << Width*(i+1)+10 << 2 << "black";
		}
}


int main()
{
	int Size, EmptyX, EmptyY, OutMode;

	//Initialization
	for ( int i=0; i<MaxN; i++ )
		for ( int j=0; j<MaxN; j++ )
			cell[i][j] = ' ';

	//Input parameters
	do
	{
		cout<<"Enter the width/height of the puzzle (2, 4, 8): ";
		cin >>Size;
		if  (! ( (Size==2) || (Size==4) || (Size==8) ) )
			cerr<<"ERROR! The width/height of the puzzle must be 2, 4 or 8"<<endl;
	} while (! ( (Size==2) || (Size==4) || (Size==8) ) );

	do
	{
		cout<<"Enter the x-coordinate of the empty cell (0-"<<Size-1<<"): ";
		cin >>EmptyX;
		if  ( (EmptyX < 0) || (EmptyX > Size-1) )
			cerr<<"ERROR! The x-coodrinate must between 0 and "<<Size-1<<endl;
	} while ( (EmptyX < 0) || (EmptyX > Size-1) );

	do
	{
		cout<<"Enter the y-coordinate of the empty cell (0-"<<Size-1<<"): ";
		cin >>EmptyY;
		if  ( (EmptyY < 0) || (EmptyY > Size-1) )
			cerr<<"ERROR! The y-coodrinate must between 0 and "<<Size-1<<endl;
	} while ( (EmptyY < 0) || (EmptyY > Size-1) );

	cout<<"(0: Console output, 1: Basic SVG output, 2 advanced SVG output)"<<endl;
	do
	{
		cout<<"Enter the output mode: ";
		cin >>OutMode;
		if  ( (OutMode < 0) || (OutMode > 2) )
			cerr<<"ERROR! The output mode must be 0, 1 or 2"<<endl;
	} while ( (OutMode < 0) || (OutMode > 2) );

	//Processing
	PrintArray(0, 0, Size, EmptyX, EmptyY);

	//Output
	switch (OutMode)
	{
	case 0 : Output0(Size); break;
	case 1 : Output1(Size); break;
	case 2 : Output2(Size); break;
	default: cout<<"ERROR! No such mode!"; return -1;
	}

	return 0;
}
