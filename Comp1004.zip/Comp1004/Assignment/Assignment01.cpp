//NAME: Tam Siu Lun
//ID: 20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Assignment 1

#include<iostream>
using namespace std;

int f (int n)
{
	return n%2?(3*n+1):n/2;
}

int Leng (int n)
{
	int Accumulator = 1;
	int Counter = n;
	while (Counter != 1)
	{
		Counter=f(Counter);
		Accumulator++;
	}
	return Accumulator;
}


int main()
{
	int s,e;

	cout<<"Enter s (for start): ";
	cin>>s;
	cout<<"Enter e (for end): ";
	cin>>e;

	int nMax      = s,
		LengthMax = 0;

	for(int i=s;i<=e;i++)
	{
		int Length = Leng(i);
		if ( LengthMax < Length )
		{
			nMax = i;
			LengthMax = Length;
		}
	}
	cout<<"n: "<<nMax<<", length: "<<LengthMax;
	return 0;
}
