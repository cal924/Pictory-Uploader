//NAME: Tam Siu Lun
//ID: 20028979
//EMAIL: calvin_924@msn.com
//		 sltamaa@stu.ust.hk
//Lab Section: LA1B
//Comp 1004 Assignment 3

#include <iostream>
using namespace std;

#include "contact.h"

extern Contact *head_contact;

bool equal(const char a[], const char b[])
{
	//TODO: Return true if strings a and b are equal
	int length = strlen(a);
	if (strlen(a) == strlen(b))
	{
		for (int i = 0 ; i < length ; i++)
		{	if (a[i] != b[i])
				return false;}
		return true;
	}
	return false;
}

bool larger(const char a[], const char b[])
{
	//TODO: Return true if string a is larger than string b, vice versa
	int lengtha = strlen(a);
	int lengthb = strlen(b);
	int length  = (lengtha>lengthb?lengthb:lengtha);
	for (int i = 0 ; i < length ; i++)
		if (a[i] != b[i])
			return (a[i] > b[i]);
	return (lengtha > lengthb);
}

void CopyStr(char dest[], const char src[])
{
	//TODO: Copy the string from src to dest
	int length = strlen(src);
	for (int i = 0 ; i < length ; i++)
		dest[i] = src[i];
	dest[length] = '\0';
}

void PrintContact(Contact* P)
{
	//TODO: Print out the contact P
	//if ( P == NULL)		return;
	cout<<"Name: "			<<P->person->name   <<endl;
	cout<<"Address: "		<<P->person->address<<endl;
	cout<<"Email: "			<<P->person->email  <<endl;
	cout<<"Phone number: "	<<P->person->phone  <<endl;
	cout<<endl;
}

void print_all_contacts()
{
	// TODO: Print all contacts in alphabetical order
	int i = 0;
	for (Contact* P = head_contact ; P != NULL ; P = P->next)
	{	//if (P ==NULL){return;}
		PrintContact(P);
		i++;
	}
	cout<<"\nTotal number of contacts: "<<i<<endl;
}

void print_out(Contact* P, int& i)
{
	//TODO: Recursive function for printing all contacts in reverse alphabetical order
	if ( P != NULL)
	{
		print_out(P->next, i);
		PrintContact(P);
		i++;
	}
	//return;
}

void print_all_contacts_in_reverse()
{
	// TODO: Print all contacts in reverse alphabetical order
	int i = 0;
	print_out(head_contact, i);
	cout<<"\nTotal number of contacts: "<<i<<endl;
}

void print_common_friends(char name1[], char name2[])
{
	// TODO: Print the common friends between two contacts
	Contact* Target1 = NULL;
	Contact* Target2 = NULL;

	//Search for the contacts
	for (Contact* P = head_contact ; P!= NULL ; P = P->next)
	{
		if ( equal(name1, P->person->name) )
			Target1 = P;
		if ( equal(name2, P->person->name) )
			Target2 = P;
		if ( (Target1 != NULL) && (Target2 != NULL) )
			break;
	}
	if ( (Target2 == NULL) || (Target2 == NULL) )
	{
		if (Target1 == NULL)
			cout<<"Contact "<<name1<<" does not exist in the system!"<<endl;
		if (Target2 == NULL)
			cout<<"Contact "<<name2<<" does not exist in the system!"<<endl;
		return;
	}

	//Check for common friends
	Person_List* Friend1 = Target1->friends;
	Person_List* Friend2 = Target2->friends;
	int i = 0;
	while ( (Friend1 != NULL)&&(Friend2 !=NULL) )
	{
		if (equal(Friend1->person->name, Friend2->person->name))
		{
			cout<<"Name: "			<<Friend1->person->name   <<endl;
			cout<<"Address: "		<<Friend1->person->address<<endl;
			cout<<"Email: "			<<Friend1->person->email  <<endl;
			cout<<"Phone number: "	<<Friend1->person->phone  <<endl;
			cout<<endl;
			i++;
			Friend1 = Friend1->next;
			Friend2 = Friend2->next;
		}
		else if (larger(Friend1->person->name, Friend2->person->name))
			Friend2 = Friend2->next;
		else
			Friend1 = Friend1->next;
	}
	cout<<"\nTotal number of common friends between "<<Target1->person->name<<" "
		<<Target2->person->name<<": "<<i<<endl;
}

void print_friends_of_contact(char name[])
{
	// TODO: Print all friends of a contact
	Contact* Target = head_contact;
	while ( (Target != NULL) && !equal(name, Target->person->name) )
		Target = Target->next;

	if (Target == NULL)
	{
		cout<<"Contact "<<name<<" does not exist in the system!"<<endl;
		return;
	}

	int i = 0;
	for (Person_List* P = Target->friends ; P != NULL ; P = P->next)
	{
		cout<<"Name: "			<<P->person->name   <<endl;
		cout<<"Address: "		<<P->person->address<<endl;
		cout<<"Email: "			<<P->person->email  <<endl;
		cout<<"Phone number: "	<<P->person->phone  <<endl;
		cout<<endl;
		i++;
	}
	cout<<"\nTotal number of friends of "<<Target->person->name<<": "<<i<<endl;
}

void test_friendship(char name1[], char name2[])
{	
	// TODO: Test friendship between two contacts
    //  The program prompts the user to enter two names. Both the contacts associated with
    //  these names must be present in the system, otherwise the user is informed. If they both
    //  exist in the system, the program returns "Yes" if the second contact is in the friend
    //  list of the first contact, and "No" otherwise.
	Contact* TargetC = NULL;
	Contact* TargetF = NULL;
	for (Contact* P = head_contact ; P!= NULL ; P = P->next)
	{
		if ( equal(name1, P->person->name) )
			TargetC = P;
		if ( equal(name2,  P->person->name) )
			TargetF = P;
		if ( (TargetC != NULL) && (TargetF != NULL) )
			break;
	}

	if ( (TargetC == NULL) || (TargetF == NULL) )
	{
		if (TargetC == NULL)
			cout<<"Contact "<<name1<<" does not exist in the system!"<<endl;
		if (TargetF == NULL)
			cout<<"Contact "<<name2<<" does not exist in the system!"<<endl;
		return;
	}

	for (Person_List* P = TargetC->friends ; P != NULL ; P = P->next)
		if (equal(name2, P->person->name))
		{
			cout<<"\nYes"<<endl;
			return;
		}
	cout<<"\nNo"<<endl;
}

void add_friend_to_contact(char contact_name[], char friend_name[])
{	
	// TODO: Add a friend to a contact
    //  The program prompts the user to enter two names. Both the contacts associated
    //  with these names must be present in the system, otherwise the user is informed.
    //  If they both exist in the system, the second contact is added in the friend list
    //  of the first contact.
	Contact* TargetC = NULL; //Pointing the contact with contact_name
	Contact* TargetF = NULL; //Pointing the contact with friend_name
	for (Contact* P = head_contact ; P!= NULL ; P = P->next)
	{
		if ( equal(contact_name, P->person->name) )
			TargetC = P;
		if ( equal(friend_name,  P->person->name) )
			TargetF = P;
		if ( (TargetC != NULL) && (TargetF != NULL) )
			break;
	}

	if ( (TargetC == NULL) || (TargetF == NULL) )
	{
		if (TargetC == NULL)
			cout<<"Contact "<<contact_name<<" does not exist in the system!"<<endl;
		if (TargetF == NULL)
			cout<<"Contact "<<friend_name<<" does not exist in the system!"<<endl;
		return;
	}

	if (TargetC->friends == NULL)
	{
		TargetC->friends = new Person_List;
		TargetC->friends->person=TargetF->person;
		TargetC->friends->next=NULL;
		return;
	}

	Person_List* P = TargetC->friends;
	while ( (P != NULL) && (P->next != NULL) && larger(friend_name, P->next->person->name))
		P = P->next;
	Person_List* NEW = new Person_List;
	NEW->person=TargetF->person;;

	NEW->next = P->next;
	P->next = NEW;
	cout<<"\nFriend added to contact!"<<endl;
}

void search_contact(char name[])
{		
	// TODO: Search a contact
    //  The user enters a name, and the program outputs the name, address, email
    //  and phone number of the stored contact having the provided name. If there is
    //  no contact in the system with the entered name, the program informs the user
    //  accordingly.
	Contact* Target = head_contact;
	while ( (Target != NULL) && !equal(name, Target->person->name) )
		Target = Target->next;
	if (Target == NULL)
		cout<<"Contact "<<name<<" does not exist in the system!"<<endl;
	else
		PrintContact(Target);
}

void delete_contact(char name[])
{	
	// TODO: Delete a contact
    //  The user provides a name, and the program deletes the contact having this
    //  name from the system, as well as from the friend lists of all the remaining
    //  contacts.
    Contact* Before = NULL;
	Contact* Current = head_contact;
	while ( (Current != NULL) && !equal(name, Current->person->name) )
	{
		Before = Current;
		Current = Current->next;
	}

	if (Current == NULL)
		cout<<"Contact "<<name<<" does not exist in the system!"<<endl;
	else if (Current == head_contact)
	{
		head_contact = Current->next;
		delete Current;
	}
	else
	{
		Before->next = Current->next;
		delete Current;
	}

	for (Contact* P = head_contact ; P != NULL ; P = P->next)
	{
		Person_List* F = P->friends;
		Person_List* Before = NULL;
		if (equal(name, P->friends->person->name))
				P->friends = NULL;
		else
			while (F != NULL)
			{
				if (equal(name, F->person->name))
				{
					Before->next = F->next;
					delete F;
					break;
				}
				Before = F;
				F = F->next;
			}

	}
	cout<<"\nContact deleted!"<<endl;
}

void add_contact(char name[], char address[], char email[], char phone[])
{
	// TODO: Add a new contact
    //  The user is prompted to enter the name, address, email and phone number of
    //  the contact to be added. Make the following two assumptions for simplicity:
    //  (i) the user always enters valid information (i.e., no formatting checks need
    //  to be performed), and (ii) the names of the contacts are unique, i.e., no two
    //  different contacts have an identical name.
	Contact* P = head_contact;
	Contact* NEW = new Contact;
	NEW->person = new Person;
	CopyStr(NEW->person->name   , name);
	CopyStr(NEW->person->address, address);
	CopyStr(NEW->person->email  , email);
	CopyStr(NEW->person->phone  , phone);
	NEW->friends=NULL;


	if (head_contact == NULL)
	{
		head_contact = NEW;
		NEW->next=NULL;
		return;
	}

	while ( (P != NULL) && (P->next != NULL) && larger(name, P->next->person->name) )
		P = P->next;
	NEW->next = P->next;
	P->next = NEW;
}
