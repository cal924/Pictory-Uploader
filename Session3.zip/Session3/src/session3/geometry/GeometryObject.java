package session3.geometry;

public class GeometryObject {
	protected String color;
	
	public GeometryObject(){
		color = "blue";
	}
	
	public String getColor(){
		return color;
	}
	
	public void setColor(String color){
		this.color = color;
	}
	
	public void draw(){
		//TODO some code to draw it on screen;
	}
	
	public void introduceYourself(){
		System.out.println("Hi, I am a geometry object");
	}
}
