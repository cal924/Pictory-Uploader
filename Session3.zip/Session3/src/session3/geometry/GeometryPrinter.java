package session3.geometry;

public class GeometryPrinter {
	public static void print(GeometryObject obj){
		obj.introduceYourself();
	}
}
