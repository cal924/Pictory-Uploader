package session3.geometry;

public class GeoTriangle extends GeometryObject {
	
	private double length;
	
	public GeoTriangle(){
		super();
	}
	
	public GeoTriangle(double length){
		this();
		this.length = length;
	}
	
	public void print(){
		GeometryPrinter.print(this);
	}
	
	public double getLength(){
		return length;
	}
	
	public double getArea(){
		return 0.5 * length * length * Math.sqrt(3) / 2;
	}
	
	@Override
	public void introduceYourself(){
		super.introduceYourself();
		System.out.println("Ahhh no, I am a circle");
	}
	
	public void introduceYourself(String target){
		System.out.println("Hi, " + target + ". I am a circle");
	}

}
