package session3.geometry;

public class GeoCircle extends GeometryObject{
	public static final double PI = 3.141592654;
	
	private double radius;
	
	public GeoCircle(double r){
		super();
		radius = r;
	}
	
	public double getRadius(){
		return radius;
	}
	
	public double getArea(){
		return PI * radius * radius;
	}
	
	@Override
	public void introduceYourself(){
		super.introduceYourself();
		System.out.println("Ahhh no, I am a circle");
	}
	
	public void introduceYourself(String target){
		System.out.println("Hi, " + target + ". I am a circle");
	}
}
