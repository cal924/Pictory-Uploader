package session3.geometry;

public class GeoRectangle extends GeometryObject {
	private double width;
	private double height;
	
	public GeoRectangle(double width, double height){
		color = "black";
		this.width = width;
		this.height = height;
	}
	
	public double getWidth(){
		return width;
	}
	
	public double getHeight(){
		return height;
	}
	
	public double getArea(){
		return width * height;
	}

	@Override
	public void introduceYourself(){
		System.out.println("Hi, I am a rectangle");
	}
}
