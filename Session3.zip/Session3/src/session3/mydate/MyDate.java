package session3.mydate;

public class MyDate {
	public int day;
	public int month;
	public int year;
	
	public MyDate(int year, int month, int day){
		this.year = year;
		this.month = month;
		this.day = day;
	}
	
	public void setYear(int newYear){
		if (newYear > 1900 && newYear < 2099){
			year = newYear;
		}
	}
	
	public void setMonth(int newMonth){
		if (newMonth >= 1 && newMonth <=12){
			month = newMonth;
		}
	}
	
	public int getYear(){
		return year;
	}
	
	public int getMonth(){
		return month;
	}
	
	public int getDay(){
		return day;
	}
	
	public boolean isSameDay(MyDate anotherDay){
		return year == anotherDay.getYear() 
				&& month == anotherDay.getMonth()
				&& day == anotherDay.getDay();
	}
}
