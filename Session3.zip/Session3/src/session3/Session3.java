package session3;

import java.io.IOException;

import session3.circle.Circle;
import session3.circle.SimpleCircle;
import session3.geometry.GeoCircle;
import session3.geometry.GeometryObject;
import session3.interfaceTest.Car;
import session3.mydate.MyDate;

public class Session3 {
	public static void main(String[] args){
		
		SimpleCircle myCircle1;
		myCircle1 = new SimpleCircle(2.0);
		
		SimpleCircle myCircle2 = new SimpleCircle(3.0);
		
		
		if (myCircle1 == myCircle2){
			
		}
		
		System.out.println("Pi = " + myCircle1.PI);
		System.out.println("Area = " + myCircle1.getArea());
		
		
		MyDate d = new MyDate(2017,5,6);
		
		d.setMonth(13);	//Can tell wrong
		d.month = 13;	//Directly assigned and cannot control
		
		
		MyDate dob = new MyDate(1992,11,30);
		MyDate birthday = dob;
		birthday.setYear(2017);	//Modifying both dob and birthday!!
		MyDate anotherDay = new MyDate(2017,11,30);
		boolean same = (anotherDay == birthday);	//it doesnt work!
		
		/*
		GeometryObject someObj1 = new GeoCircle(5);
		GeometryObject someObj2 = new GeometryObject();
		GeometryObject someObj3 = new GeoCircle();		//Constructor not defined
		GeoCircle someCircle4 = new GeoCircle(6);
		GeoCircle someCircle5 = new GeometryObject();	//Cannot cast from superclass
		
		someObj1 = someObj2;	//ok
		someObj3 = someCircle4;	//ok
		someCircle4 = someObj3;	//cannot cast from GeometryObject to GeoCircle
		someCircle4 = (GeoCircle) someObj3;	//hard code it, syntax ok
								//but if someObj3 is not circle, run time error		
		if (someObj3 instanceof GeoCircle){	//best practice before casting
			someCircle4 = (GeoCircle) someObj3;
		}
		
		someCircle4.getRadius();
		someObj3.getRadius();	//GeometryObject doesn't have the method getRadius
		((GeoCircle) someObj3).getRadius();
		if (someObj3 instanceof GeoCircle){	//best practice before casting
			((GeoCircle) someObj3).getRadius();
		}
		*/
		
		
	}
	
	public void callPolice(){
		
	}
	
	public void exceptionTrial() throws ArithmeticException{
		double dou2 = 0;
		double dou3 = 5.2 / dou2;	//divided by zero
		
		int[] array = new int[10];
		array[15] = 3;				//array index out of bound
		
		Circle c = null;
		try{
			c.getArea();				//null pointer exception
		}catch(NullPointerException e){
			System.out.println("c is null!!");
		}catch(ArithmeticException e){
			System.out.println("calcaultion goes wrong!!");
		}
	}
	
	public void exceptionTrial2(){
		Car c = new Car();
		try{
			c.start();
			c.drive();
		}catch(TrafficAccidentException e){
			callPolice();
		}finally{
			c.stop();
		}
	}
}
