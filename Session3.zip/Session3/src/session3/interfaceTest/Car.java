package session3.interfaceTest;

import session3.TrafficAccidentException;

public class Car extends Machine {
	public void start(){
		
	}
	
	public void stop(){
		
	}
	
	public void drive() throws TrafficAccidentException{
	}
}
