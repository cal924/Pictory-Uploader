package session3.interfaceTest;

public class Animal {

}
