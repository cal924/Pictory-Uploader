package session3.interfaceTest;

public interface Sayable {
	public void speak();
}
