package session3.interfaceTest;

public class Bird extends Animal implements Flyable, Sayable{

	@Override
	public void speak() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getSpeed() {
		// TODO Auto-generated method stub
		return 0;
	}

}
