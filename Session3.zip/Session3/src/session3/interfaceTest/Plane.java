package session3.interfaceTest;

public class Plane extends Machine implements Flyable{
	
	@Override
	public void fly() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getSpeed() {
		// TODO Auto-generated method stub
		return Flyable.acceleration;
	}

}
