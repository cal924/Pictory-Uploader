package session3.interfaceTest;

public interface Flyable {
	
	public final double acceleration = 0;
	
	public void fly();
	
	public double getSpeed();
	
}
