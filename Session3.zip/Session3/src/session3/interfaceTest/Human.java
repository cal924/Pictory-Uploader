package session3.interfaceTest;

public class Human implements Sayable{

	@Override
	public void speak() {
		// TODO Auto-generated method stub
		
	}

}
