package session3;

public class TrafficAccidentException extends Exception {

}
