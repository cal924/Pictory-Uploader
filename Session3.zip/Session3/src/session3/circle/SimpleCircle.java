package session3.circle;

public class SimpleCircle {
	public static final double PI = 3.141592654;
	
	private double radius = 0;
	
	public SimpleCircle(double r){
		radius = r;
	}
	
	public double getRadius(){
		return radius;
	}
	
	public double getArea(){
		return PI * radius * radius;
	}
}

