package session3.circle;

public class Circle {
	public static final double pi = 3.141592654;
	
	private double radius = 0;
	
	public Circle(int r){
		super();
		radius = r;
	}
	
	public Circle(double r){
		radius = r;
	}
	
	public double getRadius(){
		return radius;
	}
	
	private double getDiameter(){
		return 2 * radius;
	}
	
	public double getArea(){
		return pi * radius * radius;
	}
	
	public double getCircumference(){
		return pi * getDiameter();
	}
	
	public static boolean isEqualCircles(Circle c1, Circle c2){
		return c1.getRadius() == c2.getRadius();
	}
}
