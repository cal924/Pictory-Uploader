package chessGame;

public class FiveInARow extends ChessGame {

	@Override
	public boolean putChess(Coordinate c, char playerColor) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isPlayerWon(char playerColor) {
		// TODO Auto-generated method stub
		return false;
	}
}
