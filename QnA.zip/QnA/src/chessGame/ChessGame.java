package chessGame;

public abstract class ChessGame {
	
	public static final int defChessBoardSize = 15;
	
	public static final char player1 = 'B';
	public static final char player2 = 'W';
	public static final char empty = ' ';
	
	private char[][] chessBoard;
	
	public ChessGame(){
		initializeChessBoard();
	}
	
	public void initializeChessBoard(){
		//TODO create a 2D array. Set all grids to default value
	}
	public void showChessBoard(){
		//TODO implement your code to show the chess board
	}
	
	public boolean isLocationAvailable(Coordinate c){
		//TODO check if a particular location is available to put a chess
		return true;
	}
	
	public boolean putChess(Coordinate c, char playerColor){
		//TODO add a chess to the chessBoard;
		//TODO return true if the chess can be put successfully. 
		return true;
	}
	
	public abstract boolean isPlayerWon(char playerColor);
		//TODO return if a player won
		//1. Check any horizontal five chess in a row
		//2. Check any vertical five chess in a col
		//3. Chek any diagonal line
	
	public boolean isChessBoardFull(){
		//TODO return if a chess board is already full;
		return false;
	}
	
	public char getNextPlayer(){
		int player1Count = 0;
		int player2Count = 0;
		
		for (int i = 0 ; i < chessBoard.length ; i++){
			for(int j = 0 ; j < chessBoard[0].length ; j++){
				switch (chessBoard[i][j]){
				case player1 : player1Count++;break;
				case player2 : player2Count++;break;
				default: break;
				}
			}
		}
		if (isChessBoardFull()){
			return ' ';	//The game is over;
		}else{
			//Since player 1 start first, only two cases
			//Case 1, player1Count = player2Count + 1  -> player2's turn
			//Case 2, player1Count = player2Count -> player1's turn
			return player1Count > player2Count ? player2 : player1;
		}
	}
	
	public boolean isValidCoordinate(Coordinate c){
		return c.getX() >= 0 && c.getX() < chessBoard.length
				&& c.getY() >= 0 && c.getY() < chessBoard.length;
	}
	
	public boolean isGameDone(){
		return isPlayerWon(player1) || isPlayerWon(player2) || isChessBoardFull();
	}
}
