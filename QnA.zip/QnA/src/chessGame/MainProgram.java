package chessGame;

import java.util.Scanner;

public class MainProgram {

	public static ChessGame game;
	
	public static Coordinate userInputChess(Scanner s, char playerColor){
		while(true){
			System.out.println("Enter the x coordinate of Player " + playerColor + " next chess");
			int x = s.nextInt();
			System.out.println("Enter the y coordinate of Player " + playerColor + " next chess");
			int y = s.nextInt();
			Coordinate c = new Coordinate(x,y);
			if (game.isValidCoordinate(c)){
				return c;
			}
		}
	}
	
	public static void main(String[] args){
		Scanner s = new Scanner(System.in);
		while (true){
			System.out.println("Which game do you want to start?");
			System.out.println("1. Five In a Row");
			System.out.println("2. Reversi");
			String input = s.nextLine();
			if (input.equals("1") || input.equals("2")){
				if(input.equals("1")){
					game = new FiveInARow();
				}else{
					game = new Reversi();
				}
				break;
			}else{
				System.out.println("Invalid Input! Please input again");
			}
		}
		if (game != null){
			/*TODO
			 * 1. Create and initialize a new game
			 * 2. loop the following
			 * 	a. Player input a chess
			 *  b. check the game ended or win
			 * 3. Return the result. Game drawn? or user A win.
			 */
		}
		s.close();
	}
}
