package com.multiable.core.share.lib;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateLib {
	private static Date emptyDate;
	private static Date maxDate;

	public static final long dayMillis = 1000 * 60 * 60 * 24L;

	static {
		initData();
	}

	private static void initData() {
		Calendar cal = Calendar.getInstance();
		// or emptyDate should be 1975-01-01 00:00:00
		cal.set(1900, Calendar.JANUARY, 1, 0, 0, 0);
		cal.set(Calendar.MILLISECOND, 0);

		emptyDate = cal.getTime();

		cal = Calendar.getInstance();
		cal.set(9999, Calendar.DECEMBER, 31, 23, 59, 59);
		cal.set(Calendar.MILLISECOND, 0);
		maxDate = cal.getTime();
	}

	/**
	 * get value differences between start date and end end date according to
	 * date type
	 * 
	 * @param start
	 *             the first date to compare
	 * @param end
	 *             the second date to compare
	 * @param typeStr
	 *             dateType {@link DatePart}
	 * @return differences between the two dates according to date type
	 */
	public static long dateDiff(Date start, Date end, String typeStr) {
		return dateDiff(start, end, DatePart.getType(typeStr));
	}

	public static long dateDiff(Date start, Date end, DatePart part) {
		Calendar startCalendar = Calendar.getInstance();
		startCalendar.setTime(start);
		Calendar endCalendar = Calendar.getInstance();
		endCalendar.setTime(end);

		int yearDiff = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
		if (DatePart.Year.equals(part)) {
			return yearDiff;
		}

		int monthDiff = yearDiff * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
		if (DatePart.Quarter.equals(part)) {
			// March and April's quarterDiff is 1, while March and February's
			// quarterDiff is 0;
			return monthDiff / 3;
		}

		if (DatePart.Month.equals(part)) {
			return monthDiff;
		}

		if (DatePart.Week.equals(part)) {
			long weekDiff = getWeekDiff(startCalendar, endCalendar);
			// below dayDiff's calculation also work, but may not efficient when
			// many years between startDate and endDate
			// long dayDiff = weekDiff * 7 +
			// endCalendar.get(Calendar.DAY_OF_WEEK) -
			// startCalendar.get(Calendar.DAY_OF_WEEK);
			return weekDiff;
		}

		// "2013-11-07 23:59:59" and "2013-11-08 00:00:00" 's dayDiff should be
		// 1
		long dayDiff = (emptyTime(end).getTime() - emptyTime(start).getTime()) / dayMillis;
		if (DatePart.Day.equals(part)) {
			return dayDiff;
		}

		// "2013-11-07 11:59:59" and "2013-11-07 12:00:00" 's hourDiff should be
		// 1
		long hourDiff = dayDiff * 24 + endCalendar.get(Calendar.HOUR_OF_DAY) - startCalendar.get(Calendar.HOUR_OF_DAY);
		if (DatePart.Hour.equals(part)) {
			return hourDiff;
		}

		// "2013-11-07 11:16:59" and "2013-11-07 11:17:00" 's minuteDiff should
		// be 1
		long minuteDiff = hourDiff * 60 + endCalendar.get(Calendar.MINUTE) - startCalendar.get(Calendar.MINUTE);
		if (DatePart.Minute.equals(part)) {
			return minuteDiff;
		}

		// secondDiff can also be calculated by (endCalendar.getTimeInMillis() -
		// startCalendar.getTimeInMillis())/1000L;
		long secondDiff = minuteDiff * 60 + endCalendar.get(Calendar.SECOND) - startCalendar.get(Calendar.SECOND);
		if (DatePart.Second.equals(part)) {
			return secondDiff;
		}

		throw new RuntimeException("Invalid DatePart:" + part);
	}

	private static long getWeekDiff(Calendar startCalendar, Calendar endCalendar) {
		startCalendar.setMinimalDaysInFirstWeek(7);
		endCalendar.setMinimalDaysInFirstWeek(7);

		int startYear = startCalendar.get(Calendar.YEAR);
		int endYear = endCalendar.get(Calendar.YEAR);
		if (startCalendar.get(Calendar.MONTH) == Calendar.JANUARY && startCalendar.get(Calendar.WEEK_OF_YEAR) > 50) {
			startYear -= 1;
		}
		if (endCalendar.get(Calendar.MONTH) == Calendar.JANUARY && endCalendar.get(Calendar.WEEK_OF_YEAR) > 50) {
			endYear -= 1;
		}

		long weekBetweenYears = 0;
		for (int i = 0; i < Math.abs(endYear - startYear); i++) {
			if (endYear > startYear) {
				weekBetweenYears += getWeekNumOfYear(Math.min(startYear, endYear) + i);
			} else {
				weekBetweenYears -= getWeekNumOfYear(Math.min(startYear, endYear) + i);
			}
		}

		long weekDiff = weekBetweenYears + endCalendar.get(Calendar.WEEK_OF_YEAR) - startCalendar.get(Calendar.WEEK_OF_YEAR);
		return weekDiff;
	}

	private static int getWeekNumOfYear(int year) {
		Calendar cal = Calendar.getInstance();
		cal.setMinimalDaysInFirstWeek(7);
		cal.set(year, 11, 31);
		return cal.get(Calendar.WEEK_OF_YEAR);
	}

	/**
	 * add value to date according to date type
	 * 
	 * @param date
	 *             the date to be added
	 * @param value
	 *             added value
	 * @param typeStr
	 *             date type {@link DatePart}
	 * @return the changed date
	 */
	public static Date dateAdd(Date date, int value, String typeStr) {
		return dateAdd(date, value, DatePart.getType(typeStr));
	}

	public static Date dateAdd(Date date, int value, DatePart part) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		if (part == DatePart.Year) {
			calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) + value);
		} else if (part == DatePart.Month) {
			calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + value);
		} else if (part == DatePart.Quarter) {
			calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + value * 3);
		} else if (part == DatePart.Week) {
			calendar.set(Calendar.WEEK_OF_YEAR, calendar.get(Calendar.WEEK_OF_YEAR) + value);
		} else if (part == DatePart.Day) {
			calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) + value);
		} else if (part == DatePart.Minute) {
			calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + value);
		} else if (part == DatePart.Hour) {
			calendar.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY) + value);
		} else if (part == DatePart.Second) {
			calendar.set(Calendar.SECOND, calendar.get(Calendar.SECOND) + value);
		}

		return calendar.getTime();
	}

	/**
	 * get date detail value according to date type
	 * 
	 * @param date
	 *             date to be search
	 * @param typeStr
	 *             date type {@link DatePart}
	 * @return the string value of the detail date information
	 */
	public static String dateValue(Date date, String typeStr) {
		return dateValue(date, DatePart.getType(typeStr));
	}

	public static String dateValue(Date date, DatePart part) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		if (part == DatePart.Year) {
			return String.valueOf(cal.get(Calendar.YEAR));
		} else if (part == DatePart.Quarter) {
			int month = cal.get(Calendar.MONTH);
			return String.valueOf(month / 3 + 1);
		} else if (part == DatePart.Month) {
			return String.valueOf(cal.get(Calendar.MONTH) + 1);
		} else if (part == DatePart.Week) {
			return String.valueOf(cal.get(Calendar.WEEK_OF_YEAR));
		} else if (part == DatePart.Day) {
			return String.valueOf(cal.get(Calendar.DAY_OF_YEAR));
		} else if (part == DatePart.Day_Month) {
			return String.valueOf(cal.get(Calendar.DAY_OF_MONTH));
		} else if (part == DatePart.Hour) {
			return String.valueOf(cal.get(Calendar.HOUR_OF_DAY));
		} else if (part == DatePart.Minute) {
			return String.valueOf(cal.get(Calendar.MINUTE));
		} else if (part == DatePart.Second) {
			return String.valueOf(cal.get(Calendar.SECOND));
		}
		return "";
	}

	/**
	 * create date by date String and time string with date pattern
	 * 'yyyy-MM-dd',time pattern 'HH:mm:ss'
	 * 
	 * @param date
	 *             date string
	 * @param time
	 *             time string
	 * @return date generated by the date string and time string
	 */
	public static Date createDate(String dateStr, String timeStr) {
		if (dateStr == null || dateStr.isEmpty()) {
			return null;
		}
		int year = 0;
		int month = 0;
		int day = 0;

		int hour = 0;
		int minute = 0;
		int second = 0;
		int milliSecond = 0;

		try {
			dateStr = dateStr.split(" ")[0];
			String[] dateValues = dateStr.split(DateFormatLib.DEF_DATE_SEPARATOR);
			for (int i = 0; i < dateValues.length; i++) {
				if (!MathLib.isNumericStr(dateValues[i])) {
					continue;
				}
				if (i == 0) {
					year = Integer.parseInt(dateValues[i]);
				} else if (i == 1) {
					month = Integer.parseInt(dateValues[i]);
				} else if (i == 2) {
					day = Integer.parseInt(dateValues[i]);
				}
			}

			String[] timeValues = timeStr.split("\\D");
			for (int i = 0; i < timeValues.length; i++) {
				if (!MathLib.isNumericStr(timeValues[i])) {
					continue;
				}
				if (i == 0) {
					hour = Integer.parseInt(timeValues[i]);
				} else if (i == 1) {
					minute = Integer.parseInt(timeValues[i]);
				} else if (i == 2) {
					second = Integer.parseInt(timeValues[i]);
				} else if (i == 3) {
					String value = timeValues[i];
					if (timeValues[i].length() == 2) {
						value = value + "0";
					} else if (timeValues[i].length() == 1) {
						value = value + "00";
					}
					milliSecond = Integer.parseInt(value);

				}

			}
			Calendar c = Calendar.getInstance();
			c.set(year, month - 1, day, hour, minute, second);
			c.set(Calendar.MILLISECOND, milliSecond);
			return c.getTime();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static Date createDateWithFormat(String dateTimeStr, String format) {
		return DateFormatLib.createDateTime(dateTimeStr, format);
	}

	/**
	 * Get "1900-01-01" as empty time
	 * 
	 * @return
	 */
	public static Date getEmptyTime() {
		return emptyDate;
	}

	/**
	 * Return current time
	 * 
	 * @return
	 */
	public static Date getCurTime() {
		return new Date();
	}

	/**
	 * Return current date with time set to 00:00:00;
	 * 
	 * @return
	 */
	public static Date getCurDate() {
		Date now = new Date();
		return emptyTime(now);
	}

	/**
	 * Return date with time set to 00:00:00;
	 * 
	 * @param date
	 * @return
	 */
	public static Date emptyTime(Date date) {
		return DateFormatLib.createDate(dateToString(date));
	}

	/**
	 * Get Max Date 9999-12-31
	 * 
	 * @return
	 */
	public static Date getMaxDate() {
		return maxDate;
	}

	public static Date getTomorrow() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, 1);
		return cal.getTime();

	}

	public static String genShowTime(long second) {
		String st = "";
		int sec = (int) (second % 60);
		int temp = (int) (second / 60);
		if (temp > 0) {
			int min = temp % 60;
			temp = temp / 60;
			if (temp > 0) {
				int hour = temp % 24;
				temp = temp / 24;
				if (temp > 0) {
					st = temp + " days" + " " + hour + " hours";
				} else {
					st = hour + " hours" + " " + min + " minutes";
				}

			} else {
				st = min + " minutes" + " " + sec + " seconds";
			}

		} else {
			st = sec + " seconds";
		}

		return st;
	}

	/**
	 * fomat data with pattern "yyyy/MM/dd HH:mm:ss"
	 * 
	 * @param date
	 * @return
	 */
	public static String formatDate(Date date) {
		return DateFormatLib.getOrgDateFormat(date);
	}

	/**
	 * Convert date into String with format 'yyyy-MM-dd'
	 * 
	 * @param date
	 * 
	 * @return the string value of date information
	 */
	public static String dateToString(Date date) {
		if (date == null) {
			return "";
		}

		return DateFormatLib.getDateFormat(date);
	}

	public static Date parseDate(String str) {

		return DateFormatLib.createDate(str);

	}

	public static Date parseDateTime(String str) {
		if (str == null || str.isEmpty() || str.trim().isEmpty()) {
			return null;
		}

		String[] values = str.split(" ");
		if (values.length == 1) {
			if (values[0].contains(":")) {
				return DateFormatLib.createTime(str);
			} else {
				return DateFormatLib.createDate(str);
			}
		} else {
			Date date = DateFormatLib.createDateTime(str);
			return date;
		}

	}

	public static Date parseTime(String str) {

		return DateFormatLib.createTime(str);

	}

	/**
	 * format data with pattern 'yyyy-MM-dd HH:mm:ss'
	 * 
	 * @param date
	 * 
	 * @return the string value of datetime information
	 */
	public static String dateTimeToString(Date date) {
		if (date == null) {
			return "";
		}

		return DateFormatLib.getDateTimeFormat(date);
	}

	/**
	 * Convert time into String with format 'HH:mm:ss'
	 * 
	 * @param date
	 * 
	 * @return the string value of time information
	 */
	public static String timeToString(Date date) {
		if (date == null) {
			return "00:00:00";
		}
		return DateFormatLib.getTimeFormat(date);
	}

	public static String formatDate(Date date, String format) {
		if (date == null || format == null || format.isEmpty()) {
			return "";
		}
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			return sdf.format(date);
		} catch (Exception e) {
			// logger
			return formatDate(date);
		}
	}

	public static Date convertDateByTimeZone(Date date, String timeZoneId) {
		if (date == null) {
			return null;
		}
		TimeZone timeZone = TimeZone.getTimeZone(timeZoneId);
		if (timeZone == null) {
			return null;
		}
		SimpleDateFormat formater = new SimpleDateFormat(DateFormatLib.DEF_DATETIME_PATTERN);
		formater.setTimeZone(timeZone);
		String str = formater.format(date);
		String[] parts = str.split("\\s");
		if (parts == null || parts.length != 2) {
			return null;
		}
		return createDate(parts[0], parts[1]);
	}

	public static boolean isEmptyDate(Date date) {
		if (date == null) {
			return true;
		}
		String dateStr = dateToString(date);
		return dateStr.equals("1900-01-01");
	}

	public static boolean isCurTimeValid(String startTime, String endTime) {
		Date now = new Date();
		return isTimeValid(startTime, endTime, now);
	}

	public static boolean isTimeValid(String startTime, String endTime, Date time) {
		if (startTime == null || endTime == null) {
			return false;
		}
		String minStartTime = "00:00:00";
		String maxEndTime = "23:59:59";

		if (startTime.isEmpty()) {
			startTime = minStartTime;
		}
		if (endTime.isEmpty()) {
			endTime = maxEndTime;
		}
		if (startTime.equals(minStartTime) && endTime.equals(maxEndTime)) {
			return true;
		}

		Date startTimeDate = createDate(dateToString(time), startTime);
		Date endTimeDate = createDate(dateToString(time), endTime);
		if (startTimeDate == null || endTimeDate == null) {
			return false;
		}
		return time.compareTo(startTimeDate) > 0 && time.compareTo(endTimeDate) < 0;
	}

	/**
	 * for instance: 2014-2-28 16:10:56,return 2014-2-28 00:00:00
	 */
	public static Date toStartTime(Date date) {
		if (date == null) {
			return DateLib.getEmptyTime();
		}
		Date startTimeDate = createDate(dateToString(date), "00:00:00");
		return startTimeDate;
	}

	/**
	 * for instance: 2014-2-28 16:10:56,return 2014-2-28 23:59:59
	 */
	public static Date toEndTime(Date date) {
		if (date == null) {
			return DateLib.getMaxDate();
		}
		Date endTimeDate = createDate(dateToString(date), "23:59:59");
		return endTimeDate;
	}

	public static boolean isEqualsDate(Date start, Date end) {
		return dateDiff(start, end, DatePart.Second) == 0L;
	}
}
