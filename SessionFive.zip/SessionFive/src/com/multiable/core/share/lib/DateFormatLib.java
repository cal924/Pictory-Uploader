package com.multiable.core.share.lib;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class DateFormatLib {
	public final static String DEF_DATE_SEPARATOR = "-";
	public final static String DEF_DATE_PATTERN = "yyyy" + DEF_DATE_SEPARATOR + "MM" + DEF_DATE_SEPARATOR + "dd";
	public final static String DEF_TIME_SEPARATOR = ":";
	public final static String DEF_TIME_PATTERN = "HH" + DEF_TIME_SEPARATOR + "mm" + DEF_TIME_SEPARATOR + "ss";
	public final static String DEF_DATETIME_PATTERN = DEF_DATE_PATTERN + " " + DEF_TIME_PATTERN;
	public final static String DEF_DATETIME_MILLISECOND_PATTERN = DEF_DATETIME_PATTERN + ".SSS";

	private final static String FORMAT_DATETIME_PATTERN = "yyyy/MM/dd HH:mm:ss";
	private final static String FORMAT_SIMPLE_DATETIME_PATTERN = "MM/dd HH:mm";

	public static final TimeZone GMT = TimeZone.getTimeZone("GMT");

	private static ThreadLocal<Map<String, SimpleDateFormat>> threadLocal = new ThreadLocal<>();

	private static SimpleDateFormat getSimpleDateFormat(String dateFormat) {
		Map<String, SimpleDateFormat> dfs = threadLocal.get();
		if (dfs == null) {
			dfs = new HashMap<>();
			threadLocal.set(dfs);
		}

		if (dfs.containsKey(dateFormat)) {
			return dfs.get(dateFormat);
		}

		SimpleDateFormat df = new SimpleDateFormat(dateFormat);
		dfs.put(dateFormat, df);
		return df;
	}

	public static String date2Str(Date date, String dateFormat) {
		if (date == null) {
			return "";// TODO 1900-01-01?
		}
		SimpleDateFormat sdf = getSimpleDateFormat(dateFormat);
		if (sdf == null) {
			return String.valueOf(date);
		}
		String dateStr = sdf.format(date);

		return dateStr;
	}

	public static Date str2Date(String dateStr, String dateFormat) {
		if (dateStr == null || dateStr.isEmpty() || dateStr.trim().isEmpty()) {
			return null;
		}
		SimpleDateFormat sdf = getSimpleDateFormat(dateFormat);
		Date date = null;
		try {
			date = sdf.parse(dateStr);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return date;
	}

	public static String getDateFormat(Date date) {
		return date2Str(date, DEF_DATE_PATTERN);
	}

	public static String getTimeFormat(Date date) {
		return date2Str(date, DEF_TIME_PATTERN);
	}

	public static String getDateTimeFormat(Date date) {
		return date2Str(date, DEF_DATETIME_PATTERN);
	}

	public static Date createDate(String dateStr) {
		return createDate(dateStr, DEF_DATE_PATTERN);
	}

	public static Date createTime(String dateStr) {
		return createTime(dateStr, DEF_TIME_PATTERN);
	}

	public static Date createDateTime(String dateStr) {
		return createDateTime(dateStr, DEF_DATETIME_PATTERN);
	}

	public static Date createDate(String dateStr, String dateFormat) {
		return str2Date(dateStr, dateFormat);
	}

	public static Date createTime(String dateStr, String dateFormat) {
		return str2Date(dateStr, dateFormat);
	}

	public static Date createDateTime(String dateStr, String dateFormat) {
		return str2Date(dateStr, dateFormat);
	}

	public static String getOrgDateFormat(Date date) {
		return date2Str(date, FORMAT_DATETIME_PATTERN);
	}

	public static String getSimpleDateFormat(Date date) {
		return date2Str(date, FORMAT_SIMPLE_DATETIME_PATTERN);
	}
}