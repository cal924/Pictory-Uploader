package com.multiable.core.share.lib;

public enum DatePart {
	Year("y"),
	Quarter("q"),
	Month("m"),
	Week("wk"),
	Day("day"),
	Hour("hh"),
	Minute("mm"),
	Second("ss"),
	Day_Month("day_month");
	private String value;

	DatePart(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public static DatePart getType(String value) {
		if (value == null || value.isEmpty()) {
			return null;
		}
		value = value.toLowerCase();
		if (value.startsWith("y")) {

			return DatePart.Year;
		} else if (value.equals("q") || value.equals("quarter") || value.equals("qq")) {

			return DatePart.Quarter;
		} else if (value.equals("m") || value.equals("month")) {

			return DatePart.Month;
		} else if (value.equals("wk") || value.equals("week") || value.equals("w")) {

			return DatePart.Week;
		} else if (value.equals("day") || value.equals("d") || value.equals("dd")) {

			return DatePart.Day;
		} else if (value.equals("hh") || value.equals("h") || value.equals("hour")) {

			return DatePart.Hour;
		} else if (value.equals("mm") || value.equals("minute")) {

			return DatePart.Minute;
		} else if (value.equals("ss") || value.equals("second") || value.equals("seconds")) {

			return DatePart.Second;
		} else if (value.equals("day_month")) {

			return DatePart.Day_Month;
		}

		return DatePart.valueOf(value);
	}

	public static DatePart getDatePart(String myValue) {
		for (DatePart type : DatePart.values()) {
			if (type.getValue().equals(myValue)) {
				return type;
			}
		}
		return null;
	}
}
