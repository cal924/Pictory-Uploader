package com.multiable.core.share.lib;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Random;
import java.util.regex.Pattern;

public class MathLib {

	public static final DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols();

	public static final char decimalSeparator = decimalFormatSymbols.getDecimalSeparator();

	public static final String integerPattern = "##0";
	public static final String decimalPattern = integerPattern + decimalSeparator + "0##############";
	public static final String thousandPattern = "###,##0.##";

	private static final DecimalFormat decimalFormat = new DecimalFormat(decimalPattern);
	private static final DecimalFormat thousandFormat = new DecimalFormat(thousandPattern);

	public static final Pattern digitalPP = Pattern.compile("^(-?\\d*)(\\.\\d+)?$");

	// It's value is Infinity
	public static final String PositiveInfinity = Double.toString(Double.POSITIVE_INFINITY);
	// It's value is -Infinity
	public static final String NegativeInfinity = Double.toString(Double.NEGATIVE_INFINITY);
	// It's value is NaN
	public static final String NaN = Double.toString(Double.NaN);

	// It's value is max()
	public static final String SignPositiveInfinity = decimalFormatSymbols.getInfinity();
	// It's value is -min()
	public static final String SignNegativeInfinity = "-" + decimalFormatSymbols.getInfinity();
	// It's value is ?
	public static final String SignNaN = decimalFormatSymbols.getNaN();

	private static Random random = new Random();
	private static int scale = 12;

	public static double roundFloor(double x, int deciplace) {
		return round(x, deciplace, BigDecimal.ROUND_FLOOR);
	}

	public static double roundCeil(double x, int deciplace) {
		return round(x, deciplace, BigDecimal.ROUND_CEILING);
	}

	public static double round(Number x, int deciplace) {

		return round(x.doubleValue(), deciplace, BigDecimal.ROUND_HALF_UP);
	}

	public static double round(double x, int deciplace) {
		return round(x, deciplace, BigDecimal.ROUND_HALF_UP);
	}

	public static double round(double value, int deciplace, int roundmode) {
		if (Double.isNaN(value) || Double.isInfinite(value)) {
			return value;
		}

		BigDecimal myNum = new BigDecimal(Double.toString(value));

		try {

			String doubleStr = toDoubleString(value);
			int decimal = doubleStr.indexOf(".");

			if (decimal > 0) {
				doubleStr = doubleStr.substring(decimal + 1);
				if (doubleStr.startsWith("49999", deciplace)) {
					myNum = myNum.setScale(deciplace + 2, roundmode).setScale(deciplace, roundmode);
				} else {
					myNum = myNum.setScale(deciplace, roundmode);
				}
			} else {
				myNum = myNum.setScale(deciplace, roundmode);
			}

		} catch (Exception e) {
			// logger
		}

		if (abs(myNum.doubleValue()) < Math.pow(10, -deciplace - 4)) {
			return 0.0d;
		}

		return myNum.doubleValue();

	}

	public static <T extends Number, K extends Number> Number mod(T a, K b) {
		if (b.doubleValue() != 0) {
			return round(a.doubleValue() % b.doubleValue(), scale);// or 9 for
														// excel
		}
		return null;
	}

	public static Number min(Number... values) {
		if (values.length < 1) {
			return null;
		}
		Number minValue = values[0];
		for (Number value : values) {
			if (value.doubleValue() < minValue.doubleValue()) {
				minValue = value;
			}
		}
		return minValue;
	}

	public static Number max(Number... values) {
		if (values.length < 1) {
			return null;
		}
		Number maxValue = values[0];
		for (Number value : values) {
			if (value.doubleValue() > maxValue.doubleValue()) {
				maxValue = value;
			}
		}
		return maxValue;
	}

	public static double abs(double value) {
		return Math.abs(value);
	}

	public static double ceil(double value) {
		return Math.ceil(value);
	}

	public static double floor(double value) {
		return Math.floor(value);
	}

	public static int sign(double value) {
		if (value == 0.0d) {
			return 0;
		}
		return value > 0 ? 1 : -1;
	}

	public static String toDoubleString(double d) {
		decimalFormat.setRoundingMode(RoundingMode.DOWN);
		return decimalFormat.format(d);
	}

	public static Number sum(Number... values) {
		if (values.length < 1) {
			return 0;
		}
		double sum = 0;
		for (Number value : values) {
			sum += value.doubleValue();
		}
		return sum;
	}

	public static Number avg(Number... values) {
		if (values.length < 1) {
			return 0;
		}
		Number sum = sum(values);

		// deciplace = 9 for excel
		return round(sum.doubleValue() / values.length, scale);
	}

	public static boolean isNumericStr(String str) {
		if (str == null || str.isEmpty()) {
			return false;
		}
		if (str.equals(PositiveInfinity) || str.equals(NegativeInfinity) || str.equals(NaN)) {
			return true;
		}
		return digitalPP.matcher(str).matches();
	}

	public static String getNumStrByThousandSign(double value) {
		thousandFormat.setRoundingMode(RoundingMode.CEILING);
		return thousandFormat.format(value);
	}

	public static int nextInt(int d) {
		return random.nextInt(d);
	}

	public static long nextLong() {
		return random.nextLong();
	}

	public static Double parseToNumber(String value) {
		if (!isNumericStr(value)) {
			return 0d;
		}
		return Double.parseDouble(value);
	}

	public final static double getDblVal(String value) {
		return Double.parseDouble(value);
	}

	public final static int getIntVal(String value) {
		return Integer.parseInt(value);
	}

	public static boolean isNum(String... fields) {
		for (String value : fields) {
			if (value != null && !value.isEmpty()) {
				if (!digitalPP.matcher(value).matches()) {
					return false;
				}
			}
		}
		return true;
	}
}
