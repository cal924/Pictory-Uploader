
alert("plugin.js has loaded.");

/** This function is called to from the mockDialog.html window.
 *
 */
function insertString() {
	editlive.insertHTMLAtCursor(encodeURIComponent("<b>HTML Inserted by Plugin</b>"));
}