import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MainClass {
	public static void main(String[] args){
		String[] arr = {"Apple", "Boy", "Cat"};
		
		for (String s : arr){
			System.out.println(s);
		}
		
		Map<String, String> myMap = new HashMap<String, String>();
		for (Entry<String, String> ele : myMap.entrySet()){
			String key = ele.getKey();
			String value = ele.getValue();
		}
		
		for (String s : myMap.keySet()){
			System.out.println(s);
		}
		
		List<String> myList = new ArrayList<String>();
		for (String s : myList){
			
		}
		
		StringBuffer sb = new StringBuffer();
		sb.append("Hi, Tom.");
		sb.append("My name is Calvin");
		sb.append("Welcome :)");
		
		System.out.println(sb.toString());
		
		long i = Math.round(3.52);
		double d = Math.pow(3, 5);
		double x = Math.log(2.71828);
	}
}
