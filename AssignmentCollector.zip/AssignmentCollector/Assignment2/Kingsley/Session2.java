package Assignment;

import java.util.Scanner;

public class Session2 {
	public static void leapYear(){
		Scanner reader = new Scanner(System.in);
		while (1==1){
			System.out.print("Input a year: ");
			int year = reader.nextInt();
			int modulus = year %400;
			if (modulus==0) {
				System.out.println("" + year + " is a leap year.");
			}else{
				modulus = year %4;
				if (modulus==0){
					modulus = year %100;
					if (modulus == 0){
							System.out.println("" + year + " is not a leap year.");
						}else{
							System.out.println("" + year + " is a leap year.");
						}
				}else{
					System.out.println("" + year + " is not a leap year.");
				}
			}	
			if (year==9999){break;}
		}
		reader.close();
	}
	
	public static void main(String args[]){
		leapYear();
		
		
		
		/*Scanner reader = new Scanner(System.in);
		while (1==1){
			System.out.print("Input a year: ");
			int year = reader.nextInt();
			int modulus = year %400;
			if (modulus==0) {
				System.out.println("" + year + " is a leap year.");
			}else{
				modulus = year %4;
				if (modulus==0){
					modulus = year %100;
					if (modulus == 0){
							System.out.println("" + year + " is not a leap year.");
						}else{
							System.out.println("" + year + " is a leap year.");
						}
				}else{
					System.out.println("" + year + " is not a leap year.");
				}
			}	
			if (year==9999){break;}
		}
		reader.close();
		*/
		
		
		
		
		
		
		
		/*char space = ' ';
		char star = '*';
		for (int i=1; i<=10; i++){
			for (int j=1; j<=10; j++){
				if (11-i-j>0){System.out.print(space);}else{System.out.print(star);}
			}
			System.out.println("");
		}
		*/
		
		
		/*int counter = 1;
		int temp = 5;
		while (temp < 1000000){
			temp*=5;
			if(temp < 1000000){counter++;}
		}		
		System.out.println("The largest exponential of 5 which is smaller than 1,000,000 is "+ counter);
		*/
		
	}
}
