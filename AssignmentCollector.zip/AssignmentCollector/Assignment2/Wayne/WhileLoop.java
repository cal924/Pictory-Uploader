
public class WhileLoop {

	public static void main(String[] args) {
		int base = 5;
		int power = 1;
		double result = base;

		while (result < 1000000) {
			power++;
			result = result * base;
		}
		power--;
		double maxvalue = result / base;
		System.out.println("The largest exponential of 5 which is smaller than 1,000,000 is " + maxvalue + " (" + base
				+ " to the power of " + power + ")");
	}

}
