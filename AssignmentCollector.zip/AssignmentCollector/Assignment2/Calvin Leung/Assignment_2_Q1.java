package helloWorld;

public class Assignment_2_Q1 {
	public static void main(String args[]) {

		int num = 1;
		int i = 0;

		for (i = 0; num * 5 < 1000000; i++) {
			num = num * 5;
		}
		System.out.println("The the largest exponential of 5 which is smaller than 1,000,000 is " + i);
		System.out.println("Result = " + num);
	}
}
