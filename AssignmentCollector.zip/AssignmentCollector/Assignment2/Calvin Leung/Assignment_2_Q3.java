package helloWorld;

import java.util.Scanner;

public class Assignment_2_Q3 {

	private static Scanner reader;

	public static void main(String args[]) {

		reader = new Scanner(System.in);
		int n = reader.nextInt();
		// System.out.println(n);

		if (n % 400 == 0) {
			System.out.println("This is a leap year.");
		} else if ((n % 4 == 0) && (n % 100 != 0)) {
			System.out.println("This is a leap year.");
		} else {
			System.out.println("This is NOT a leap year.");
		}
	}
}