package assignment2;

import java.util.Scanner;

public class LeapYear {
	public static void main(String args[]) {
		Scanner reader = new Scanner(System.in);
		System.out.println("Enter a Year: ");
		int n = reader.nextInt();
		if (((n % 4 == 0) && (n % 100 > 0)) || (n % 400 == 0)) {
			System.out.println("Year " + n + " is a leap year.");
		} else {
			System.out.println("Year " + n + " is NOT a leap year.");
		}
	}
}
