package assignment2;

public class LargestExponential {
	public static void main(String args[]) {
		int base = 5;
		int x = 1;
		double result = base;

		while (result < 1000000) {
			result = result * base;
			x++;
		}
		System.out.println("The largest exponential of 5 which is smaller than 1,000,000 is " + result / base);
		System.out.println("The max value of x is " + (x - 1));
	}
}
