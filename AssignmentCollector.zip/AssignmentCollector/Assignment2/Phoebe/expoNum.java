package ClassTwo;

public class expoNum {
	//Method 1: Use while-loop
	public static void main(String[] args) {
		int y = 5;
		int x = 1;
		while(y < 1000000) {
			y = y*5;
			x = x+1;
		}
		//y = y/5;
		//x = x-1;
		System.out.println("The largest exponential of 5 which is smaller than 1000000 is "+y/5+".");
		System.out.println("The corresponding power index is "+(x-1)+".");
		
	}

}
