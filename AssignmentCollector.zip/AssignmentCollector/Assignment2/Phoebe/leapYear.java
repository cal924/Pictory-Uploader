package ClassTwo;

import java.util.Scanner;// needs to import java.util.Scanner before using Scanner

public class leapYear {
	
	public static void main(String[] args) {
	Scanner reader = new Scanner(System.in);
	System.out.println("Enter a Year: ");
	int n = reader.nextInt();
	System.out.println("You've input "+n+".");
	reader.close();
	
	if (n%400 == 0) {
		System.out.println(n+" is a leap year.");
		}
	else if(n%4 == 0 && n%100 != 0) {
		System.out.println(n+" is a leap year.");
		}
	else {
		System.out.println(n+" is not a leap year.");
		}
	}

}
