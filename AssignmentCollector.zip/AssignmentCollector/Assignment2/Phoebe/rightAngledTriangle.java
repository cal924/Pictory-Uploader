package ClassTwo;

public class rightAngledTriangle {

	public static void main(String[] args) {
		int i;
		int j;
		for(i = 1;i <= 10;i++) {
			for(j = 1; j <= 10-i; j++) {
				System.out.print(" ");
			}
			for(j = 10; j > 10-i; j--) {
				System.out.print("*");
			}
			System.out.println("");
			
		}
	}
	
}
