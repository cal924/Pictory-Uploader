package helloWorld;

public class Asg2Q1 {

	public static void main(String[] args) {
		int base = 5;
		int power = 0;
		int result = 1;
		while (result < 1000000) {
			result *= base;
			power++;
		}
		power--;
		result /= base;
		System.out.println(
				"Q1. x = " + power + "\n" + "As the result " + base + " to the power " + power + " = " + result);

	}
}