package Assignment;

public class Session1 {
	public static void main(String args[]){
		System.out.println("Hello, Kingsley");
		int radius = 5;
		int diameter = radius * 2;
		double pi = 3.14159;
		System.out.println("The circumference of the circle is " + (diameter * pi));
	}
}
