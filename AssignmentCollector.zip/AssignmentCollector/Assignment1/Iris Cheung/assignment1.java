package assignment1;

public class assignment1 {
	public static void main(String args[]) {
		System.out.println("Hello, Iris Cheung");
		int radius = 5;
		int diameter = radius * 2;
		final double pi = 3.14159;
		double circumference = diameter * pi;
		System.out.println("The circumference of the circle is " + circumference);
	}
}
