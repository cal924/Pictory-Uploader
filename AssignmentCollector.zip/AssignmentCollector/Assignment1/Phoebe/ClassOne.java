package exerciseone;

public class ClassOne {
	
	public static void main(String args[]) {
		
		String myName = "Phoebe";
		System.out.println("Hello, "+ myName);
		int radius = 5;
		int diameter = radius*2;
		final double pi = 3.14159;
		double circumference = diameter*pi;
		System.out.println("The circumference of the circle is " + circumference);
	}

}
