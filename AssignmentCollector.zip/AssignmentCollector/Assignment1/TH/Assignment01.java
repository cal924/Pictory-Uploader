package Assignment01_TH;

public class Assignment01 {
	
	public static void main(String args[]) {
	/* output name */
		
	System.out.println("Hello, Tai Hung");
	
	/* calculate circumference */
	
	int  radius =5;
	int diameter = radius * 2;
			
	final double pi=3.14159;
	
	double circumference = diameter * pi;
	
	System.out.println("The circumference of the circle of radius equals to " + radius + " is "+ circumference);
	
	
	}
}
