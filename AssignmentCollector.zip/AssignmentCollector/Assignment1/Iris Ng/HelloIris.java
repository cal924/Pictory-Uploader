package helloWorld;

public class HelloIris {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hellow, Iris");

		double radius = 5;
		double diameter = radius * 2;
		System.out.println(diameter);

		final double pi = 3.14159;
		double circumference = diameter * pi;
		System.out.println("The circumference of the circle is " + circumference);
	}
}
