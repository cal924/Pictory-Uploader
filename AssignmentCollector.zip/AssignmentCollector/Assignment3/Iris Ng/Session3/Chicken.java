package Session3;

public class Chicken extends Bird implements LivingThing {

	final double NumberOfEggsPerMonth = 1;

	public Chicken() {
		super();
	}

	public Chicken(String name) {
		super();
		this.name = name;
	}

	@Override
	public void grow() {
		this.length = this.length + 2;
	}
}