package Session3;

public interface LivingThing {

	public void grow();
}
