package Session3;

public class Bird {

	public String Color;
	public double length;
	public String name;

	public Bird() {
		Color = "Black";
		length = 5;
		name = "General Bird";
	}

	public Bird(String name) {
		this();
		this.name = name;
	}

	public void move() {
		System.out.println("Walking around");
	}

	public void smile() {
		System.out.println("Smile :)");
	}
}