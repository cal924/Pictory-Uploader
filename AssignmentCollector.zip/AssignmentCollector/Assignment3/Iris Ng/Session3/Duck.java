package Session3;

public class Duck extends Bird implements LivingThing {

	double SpeedOfSwim = 5.2;

	public Duck() {
		super();
	}

	public Duck(String name) {
		super();
		this.name = name;
	}

	public Duck(String name, double SpeedOfSwim) {
		super();
		this.name = name;
		this.SpeedOfSwim = SpeedOfSwim;
	}

	public void swim() {
		System.out.println("Swimming" + " at the speed " + SpeedOfSwim);
	}

	@Override
	public void grow() {
		this.length = this.length + 1;
		this.SpeedOfSwim = this.SpeedOfSwim + 1;
	}
}