package Session3;

public class Running {

	public static void main(String[] arg) {
		Bird a = new Bird();
		a.move();
		a.smile();

		Duck Iris = new Duck("Iris");
		Iris.swim();
		Iris.grow();
		Iris.swim();
	}
}
