package Session3;

public class ToyDuck extends Bird {

	String Material;
	String Manufacturer;

	public ToyDuck() {
		super();
		this.Material = "Plastic";
		this.Manufacturer = "ABC Company";
	}

	public ToyDuck(String name, String Material, String Manufacturer) {
		super();
		this.name = name;
		this.Material = Material;
		this.Manufacturer = Manufacturer;
	}
}